﻿
namespace GymManagementSystem
{
    partial class frmStaff
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label26 = new System.Windows.Forms.Label();
            this.staffTabPanel = new MetroFramework.Controls.MetroTabControl();
            this.staffTabAdd = new MetroFramework.Controls.MetroTabPage();
            this.dateTimePickerDOB = new System.Windows.Forms.DateTimePicker();
            this.dateTimePickerJoinDate = new System.Windows.Forms.DateTimePicker();
            this.comboBoxType = new System.Windows.Forms.ComboBox();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.txt_empId = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.radioButtonFemale = new System.Windows.Forms.RadioButton();
            this.radioButtonMale = new System.Windows.Forms.RadioButton();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnBrowse = new System.Windows.Forms.Button();
            this.txtNIC = new System.Windows.Forms.TextBox();
            this.txtAge = new System.Windows.Forms.TextBox();
            this.txtLName = new System.Windows.Forms.TextBox();
            this.txtFname = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtPhoneTwo = new System.Windows.Forms.TextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.txtFax = new System.Windows.Forms.TextBox();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.txtPhoneOne = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.picBoxProfile = new System.Windows.Forms.PictureBox();
            this.staffTabDelete = new MetroFramework.Controls.MetroTabPage();
            this.btnClear2 = new System.Windows.Forms.Button();
            this.buttonShow = new System.Windows.Forms.Button();
            this.dataGridView1staff = new System.Windows.Forms.DataGridView();
            this.btnDelete = new System.Windows.Forms.Button();
            this.txtEmpId = new System.Windows.Forms.TextBox();
            this.lblMemberId = new System.Windows.Forms.Label();
            this.staffTabUpdate = new MetroFramework.Controls.MetroTabPage();
            this.comboBox1type = new System.Windows.Forms.ComboBox();
            this.dateTimePickerDOBS = new System.Windows.Forms.DateTimePicker();
            this.dateTimePickerJOD = new System.Windows.Forms.DateTimePicker();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.rbFemale = new System.Windows.Forms.RadioButton();
            this.rbMale = new System.Windows.Forms.RadioButton();
            this.btnUpload = new System.Windows.Forms.Button();
            this.buttonView = new System.Windows.Forms.Button();
            this.buttonClear = new System.Windows.Forms.Button();
            this.buttonUpdate = new System.Windows.Forms.Button();
            this.pictureBoxUpdate = new System.Windows.Forms.PictureBox();
            this.dataGridView2updateStaff = new System.Windows.Forms.DataGridView();
            this.addressTxt = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.faxTxt = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.emailTxt = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.tel2Txt = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.tel1Txt = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.nicTxt = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.ageTxt = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.lnameTxt = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.fnameTxt = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.empIdTxt = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.staffTabView = new MetroFramework.Controls.MetroTabPage();
            this.btnView = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.txt_search = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.dataGridView3Search = new System.Windows.Forms.DataGridView();
            this.staffTabPanel.SuspendLayout();
            this.staffTabAdd.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxProfile)).BeginInit();
            this.staffTabDelete.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1staff)).BeginInit();
            this.staffTabUpdate.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxUpdate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2updateStaff)).BeginInit();
            this.staffTabView.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3Search)).BeginInit();
            this.SuspendLayout();
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(27, 9);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(212, 29);
            this.label26.TabIndex = 5;
            this.label26.Text = "Staff  Management";
            // 
            // staffTabPanel
            // 
            this.staffTabPanel.Controls.Add(this.staffTabAdd);
            this.staffTabPanel.Controls.Add(this.staffTabDelete);
            this.staffTabPanel.Controls.Add(this.staffTabUpdate);
            this.staffTabPanel.Controls.Add(this.staffTabView);
            this.staffTabPanel.Location = new System.Drawing.Point(32, 41);
            this.staffTabPanel.Name = "staffTabPanel";
            this.staffTabPanel.SelectedIndex = 3;
            this.staffTabPanel.Size = new System.Drawing.Size(855, 494);
            this.staffTabPanel.TabIndex = 4;
            this.staffTabPanel.Theme = MetroFramework.MetroThemeStyle.Light;
            this.staffTabPanel.UseSelectable = true;
            this.staffTabPanel.UseStyleColors = true;
            // 
            // staffTabAdd
            // 
            this.staffTabAdd.Controls.Add(this.dateTimePickerDOB);
            this.staffTabAdd.Controls.Add(this.dateTimePickerJoinDate);
            this.staffTabAdd.Controls.Add(this.comboBoxType);
            this.staffTabAdd.Controls.Add(this.label29);
            this.staffTabAdd.Controls.Add(this.label28);
            this.staffTabAdd.Controls.Add(this.txt_empId);
            this.staffTabAdd.Controls.Add(this.label12);
            this.staffTabAdd.Controls.Add(this.radioButtonFemale);
            this.staffTabAdd.Controls.Add(this.radioButtonMale);
            this.staffTabAdd.Controls.Add(this.btnExit);
            this.staffTabAdd.Controls.Add(this.btnClear);
            this.staffTabAdd.Controls.Add(this.btnAdd);
            this.staffTabAdd.Controls.Add(this.btnBrowse);
            this.staffTabAdd.Controls.Add(this.txtNIC);
            this.staffTabAdd.Controls.Add(this.txtAge);
            this.staffTabAdd.Controls.Add(this.txtLName);
            this.staffTabAdd.Controls.Add(this.txtFname);
            this.staffTabAdd.Controls.Add(this.label5);
            this.staffTabAdd.Controls.Add(this.label6);
            this.staffTabAdd.Controls.Add(this.label3);
            this.staffTabAdd.Controls.Add(this.label4);
            this.staffTabAdd.Controls.Add(this.label2);
            this.staffTabAdd.Controls.Add(this.label1);
            this.staffTabAdd.Controls.Add(this.groupBox1);
            this.staffTabAdd.Controls.Add(this.picBoxProfile);
            this.staffTabAdd.HorizontalScrollbarBarColor = true;
            this.staffTabAdd.HorizontalScrollbarHighlightOnWheel = false;
            this.staffTabAdd.HorizontalScrollbarSize = 10;
            this.staffTabAdd.Location = new System.Drawing.Point(4, 38);
            this.staffTabAdd.Name = "staffTabAdd";
            this.staffTabAdd.Size = new System.Drawing.Size(847, 452);
            this.staffTabAdd.TabIndex = 0;
            this.staffTabAdd.Text = "Add";
            this.staffTabAdd.VerticalScrollbarBarColor = true;
            this.staffTabAdd.VerticalScrollbarHighlightOnWheel = false;
            this.staffTabAdd.VerticalScrollbarSize = 10;
            this.staffTabAdd.Click += new System.EventHandler(this.staffTabAdd_Click);
            // 
            // dateTimePickerDOB
            // 
            this.dateTimePickerDOB.CustomFormat = "yyyy-MM-dd";
            this.dateTimePickerDOB.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePickerDOB.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePickerDOB.Location = new System.Drawing.Point(111, 396);
            this.dateTimePickerDOB.Name = "dateTimePickerDOB";
            this.dateTimePickerDOB.Size = new System.Drawing.Size(132, 24);
            this.dateTimePickerDOB.TabIndex = 47;
            // 
            // dateTimePickerJoinDate
            // 
            this.dateTimePickerJoinDate.CustomFormat = "yyyy-MM-dd";
            this.dateTimePickerJoinDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePickerJoinDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePickerJoinDate.Location = new System.Drawing.Point(459, 103);
            this.dateTimePickerJoinDate.Name = "dateTimePickerJoinDate";
            this.dateTimePickerJoinDate.Size = new System.Drawing.Size(132, 24);
            this.dateTimePickerJoinDate.TabIndex = 46;
            // 
            // comboBoxType
            // 
            this.comboBoxType.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxType.FormattingEnabled = true;
            this.comboBoxType.Items.AddRange(new object[] {
            "manager",
            "trainer",
            "instructor",
            "security",
            "junitor"});
            this.comboBoxType.Location = new System.Drawing.Point(459, 63);
            this.comboBoxType.Name = "comboBoxType";
            this.comboBoxType.Size = new System.Drawing.Size(132, 26);
            this.comboBoxType.TabIndex = 45;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label29.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(334, 103);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(88, 20);
            this.label29.TabIndex = 43;
            this.label29.Text = "Joined Date";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label28.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(14, 396);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(40, 20);
            this.label28.TabIndex = 41;
            this.label28.Text = "DOB";
            // 
            // txt_empId
            // 
            this.txt_empId.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_empId.Location = new System.Drawing.Point(111, 191);
            this.txt_empId.Name = "txt_empId";
            this.txt_empId.Size = new System.Drawing.Size(132, 24);
            this.txt_empId.TabIndex = 40;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label12.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(14, 195);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(90, 20);
            this.label12.TabIndex = 39;
            this.label12.Text = "Empoyee ID";
            // 
            // radioButtonFemale
            // 
            this.radioButtonFemale.AutoSize = true;
            this.radioButtonFemale.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.radioButtonFemale.Location = new System.Drawing.Point(524, 32);
            this.radioButtonFemale.Name = "radioButtonFemale";
            this.radioButtonFemale.Size = new System.Drawing.Size(75, 21);
            this.radioButtonFemale.TabIndex = 38;
            this.radioButtonFemale.TabStop = true;
            this.radioButtonFemale.Text = "Female";
            this.radioButtonFemale.UseVisualStyleBackColor = false;
            // 
            // radioButtonMale
            // 
            this.radioButtonMale.AutoSize = true;
            this.radioButtonMale.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.radioButtonMale.Location = new System.Drawing.Point(459, 31);
            this.radioButtonMale.Name = "radioButtonMale";
            this.radioButtonMale.Size = new System.Drawing.Size(59, 21);
            this.radioButtonMale.TabIndex = 37;
            this.radioButtonMale.TabStop = true;
            this.radioButtonMale.Text = "Male";
            this.radioButtonMale.UseVisualStyleBackColor = false;
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.btnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnExit.Image = global::GymManagementSystem.Properties.Resources.exit__1_;
            this.btnExit.Location = new System.Drawing.Point(706, 404);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(127, 39);
            this.btnExit.TabIndex = 36;
            this.btnExit.Text = "Exit";
            this.btnExit.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnExit.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnExit.UseVisualStyleBackColor = false;
            // 
            // btnClear
            // 
            this.btnClear.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.btnClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnClear.Image = global::GymManagementSystem.Properties.Resources.edit_clear__1_;
            this.btnClear.Location = new System.Drawing.Point(573, 404);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(127, 39);
            this.btnClear.TabIndex = 35;
            this.btnClear.Text = "Clear";
            this.btnClear.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.btnAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnAdd.Image = global::GymManagementSystem.Properties.Resources.Save__1_;
            this.btnAdd.Location = new System.Drawing.Point(431, 404);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(127, 39);
            this.btnAdd.TabIndex = 34;
            this.btnAdd.Text = "Add";
            this.btnAdd.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnAdd.UseVisualStyleBackColor = false;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click_1);
            // 
            // btnBrowse
            // 
            this.btnBrowse.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnBrowse.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnBrowse.Image = global::GymManagementSystem.Properties.Resources._2_050;
            this.btnBrowse.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnBrowse.Location = new System.Drawing.Point(144, 125);
            this.btnBrowse.Name = "btnBrowse";
            this.btnBrowse.Size = new System.Drawing.Size(127, 45);
            this.btnBrowse.TabIndex = 33;
            this.btnBrowse.Text = "Browse";
            this.btnBrowse.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnBrowse.UseVisualStyleBackColor = false;
            this.btnBrowse.Click += new System.EventHandler(this.btnBrowse_Click_1);
            // 
            // txtNIC
            // 
            this.txtNIC.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNIC.Location = new System.Drawing.Point(111, 359);
            this.txtNIC.Name = "txtNIC";
            this.txtNIC.Size = new System.Drawing.Size(132, 24);
            this.txtNIC.TabIndex = 32;
            // 
            // txtAge
            // 
            this.txtAge.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAge.Location = new System.Drawing.Point(111, 317);
            this.txtAge.Name = "txtAge";
            this.txtAge.Size = new System.Drawing.Size(132, 24);
            this.txtAge.TabIndex = 29;
            // 
            // txtLName
            // 
            this.txtLName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLName.Location = new System.Drawing.Point(111, 275);
            this.txtLName.Name = "txtLName";
            this.txtLName.Size = new System.Drawing.Size(132, 24);
            this.txtLName.TabIndex = 28;
            // 
            // txtFname
            // 
            this.txtFname.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFname.Location = new System.Drawing.Point(111, 229);
            this.txtFname.Name = "txtFname";
            this.txtFname.Size = new System.Drawing.Size(132, 24);
            this.txtFname.TabIndex = 27;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(334, 63);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(40, 20);
            this.label5.TabIndex = 26;
            this.label5.Text = "Type";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(14, 363);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(33, 20);
            this.label6.TabIndex = 25;
            this.label6.Text = "NIC";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(334, 31);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(57, 20);
            this.label3.TabIndex = 24;
            this.label3.Text = "Gender";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(14, 321);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(36, 20);
            this.label4.TabIndex = 23;
            this.label4.Text = "Age";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(14, 277);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 20);
            this.label2.TabIndex = 22;
            this.label2.Text = "Last Name";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(14, 233);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 20);
            this.label1.TabIndex = 21;
            this.label1.Text = "First Name";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.groupBox1.Controls.Add(this.txtPhoneTwo);
            this.groupBox1.Controls.Add(this.txtEmail);
            this.groupBox1.Controls.Add(this.txtFax);
            this.groupBox1.Controls.Add(this.txtAddress);
            this.groupBox1.Controls.Add(this.txtPhoneOne);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Location = new System.Drawing.Point(326, 161);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(507, 222);
            this.groupBox1.TabIndex = 13;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Contact Details";
            // 
            // txtPhoneTwo
            // 
            this.txtPhoneTwo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPhoneTwo.Location = new System.Drawing.Point(133, 65);
            this.txtPhoneTwo.Name = "txtPhoneTwo";
            this.txtPhoneTwo.Size = new System.Drawing.Size(352, 24);
            this.txtPhoneTwo.TabIndex = 37;
            // 
            // txtEmail
            // 
            this.txtEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmail.Location = new System.Drawing.Point(133, 139);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(352, 24);
            this.txtEmail.TabIndex = 36;
            // 
            // txtFax
            // 
            this.txtFax.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFax.Location = new System.Drawing.Point(133, 172);
            this.txtFax.Name = "txtFax";
            this.txtFax.Size = new System.Drawing.Size(352, 24);
            this.txtFax.TabIndex = 35;
            // 
            // txtAddress
            // 
            this.txtAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAddress.Location = new System.Drawing.Point(133, 102);
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(352, 24);
            this.txtAddress.TabIndex = 34;
            // 
            // txtPhoneOne
            // 
            this.txtPhoneOne.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPhoneOne.Location = new System.Drawing.Point(133, 28);
            this.txtPhoneOne.Name = "txtPhoneOne";
            this.txtPhoneOne.Size = new System.Drawing.Size(352, 24);
            this.txtPhoneOne.TabIndex = 33;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label10.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(19, 174);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(30, 20);
            this.label10.TabIndex = 31;
            this.label10.Text = "Fax";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label11.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(19, 139);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(46, 20);
            this.label11.TabIndex = 30;
            this.label11.Text = "Email";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(19, 104);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(62, 20);
            this.label7.TabIndex = 29;
            this.label7.Text = "Address";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(19, 69);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(90, 20);
            this.label8.TabIndex = 28;
            this.label8.Text = "Telephone 2";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(19, 32);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(90, 20);
            this.label9.TabIndex = 27;
            this.label9.Text = "Telephone 1";
            // 
            // picBoxProfile
            // 
            this.picBoxProfile.Image = global::GymManagementSystem.Properties.Resources.User_Folder__1_;
            this.picBoxProfile.Location = new System.Drawing.Point(55, 18);
            this.picBoxProfile.Name = "picBoxProfile";
            this.picBoxProfile.Size = new System.Drawing.Size(147, 146);
            this.picBoxProfile.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBoxProfile.TabIndex = 12;
            this.picBoxProfile.TabStop = false;
            // 
            // staffTabDelete
            // 
            this.staffTabDelete.Controls.Add(this.btnClear2);
            this.staffTabDelete.Controls.Add(this.buttonShow);
            this.staffTabDelete.Controls.Add(this.dataGridView1staff);
            this.staffTabDelete.Controls.Add(this.btnDelete);
            this.staffTabDelete.Controls.Add(this.txtEmpId);
            this.staffTabDelete.Controls.Add(this.lblMemberId);
            this.staffTabDelete.HorizontalScrollbarBarColor = true;
            this.staffTabDelete.HorizontalScrollbarHighlightOnWheel = false;
            this.staffTabDelete.HorizontalScrollbarSize = 10;
            this.staffTabDelete.Location = new System.Drawing.Point(4, 38);
            this.staffTabDelete.Name = "staffTabDelete";
            this.staffTabDelete.Size = new System.Drawing.Size(847, 452);
            this.staffTabDelete.TabIndex = 1;
            this.staffTabDelete.Text = "Delete";
            this.staffTabDelete.VerticalScrollbarBarColor = true;
            this.staffTabDelete.VerticalScrollbarHighlightOnWheel = false;
            this.staffTabDelete.VerticalScrollbarSize = 10;
            // 
            // btnClear2
            // 
            this.btnClear2.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.btnClear2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnClear2.Image = global::GymManagementSystem.Properties.Resources.edit_clear__1_;
            this.btnClear2.Location = new System.Drawing.Point(661, 37);
            this.btnClear2.Name = "btnClear2";
            this.btnClear2.Size = new System.Drawing.Size(132, 38);
            this.btnClear2.TabIndex = 8;
            this.btnClear2.Text = "Clear";
            this.btnClear2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnClear2.UseVisualStyleBackColor = false;
            // 
            // buttonShow
            // 
            this.buttonShow.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.buttonShow.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonShow.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.buttonShow.Image = global::GymManagementSystem.Properties.Resources.eye;
            this.buttonShow.Location = new System.Drawing.Point(26, 79);
            this.buttonShow.Name = "buttonShow";
            this.buttonShow.Size = new System.Drawing.Size(132, 38);
            this.buttonShow.TabIndex = 7;
            this.buttonShow.Text = "Show";
            this.buttonShow.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.buttonShow.UseVisualStyleBackColor = false;
            this.buttonShow.Click += new System.EventHandler(this.buttonShow_Click);
            // 
            // dataGridView1staff
            // 
            this.dataGridView1staff.AllowUserToAddRows = false;
            this.dataGridView1staff.AllowUserToDeleteRows = false;
            this.dataGridView1staff.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dataGridView1staff.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1staff.Location = new System.Drawing.Point(28, 123);
            this.dataGridView1staff.Name = "dataGridView1staff";
            this.dataGridView1staff.ReadOnly = true;
            this.dataGridView1staff.RowHeadersWidth = 51;
            this.dataGridView1staff.RowTemplate.Height = 24;
            this.dataGridView1staff.Size = new System.Drawing.Size(765, 305);
            this.dataGridView1staff.TabIndex = 5;
            this.dataGridView1staff.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1member_CellClick);
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.btnDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnDelete.Image = global::GymManagementSystem.Properties.Resources.delete__1_;
            this.btnDelete.Location = new System.Drawing.Point(523, 35);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(132, 38);
            this.btnDelete.TabIndex = 4;
            this.btnDelete.Text = "Delete";
            this.btnDelete.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // txtEmpId
            // 
            this.txtEmpId.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmpId.Location = new System.Drawing.Point(190, 35);
            this.txtEmpId.Name = "txtEmpId";
            this.txtEmpId.Size = new System.Drawing.Size(192, 24);
            this.txtEmpId.TabIndex = 3;
            // 
            // lblMemberId
            // 
            this.lblMemberId.AutoSize = true;
            this.lblMemberId.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblMemberId.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblMemberId.Location = new System.Drawing.Point(22, 35);
            this.lblMemberId.Name = "lblMemberId";
            this.lblMemberId.Size = new System.Drawing.Size(145, 20);
            this.lblMemberId.TabIndex = 2;
            this.lblMemberId.Text = "Enter the member id";
            // 
            // staffTabUpdate
            // 
            this.staffTabUpdate.Controls.Add(this.comboBox1type);
            this.staffTabUpdate.Controls.Add(this.dateTimePickerDOBS);
            this.staffTabUpdate.Controls.Add(this.dateTimePickerJOD);
            this.staffTabUpdate.Controls.Add(this.label30);
            this.staffTabUpdate.Controls.Add(this.label31);
            this.staffTabUpdate.Controls.Add(this.rbFemale);
            this.staffTabUpdate.Controls.Add(this.rbMale);
            this.staffTabUpdate.Controls.Add(this.btnUpload);
            this.staffTabUpdate.Controls.Add(this.buttonView);
            this.staffTabUpdate.Controls.Add(this.buttonClear);
            this.staffTabUpdate.Controls.Add(this.buttonUpdate);
            this.staffTabUpdate.Controls.Add(this.pictureBoxUpdate);
            this.staffTabUpdate.Controls.Add(this.dataGridView2updateStaff);
            this.staffTabUpdate.Controls.Add(this.addressTxt);
            this.staffTabUpdate.Controls.Add(this.label25);
            this.staffTabUpdate.Controls.Add(this.textBox9);
            this.staffTabUpdate.Controls.Add(this.label21);
            this.staffTabUpdate.Controls.Add(this.faxTxt);
            this.staffTabUpdate.Controls.Add(this.label22);
            this.staffTabUpdate.Controls.Add(this.emailTxt);
            this.staffTabUpdate.Controls.Add(this.label23);
            this.staffTabUpdate.Controls.Add(this.tel2Txt);
            this.staffTabUpdate.Controls.Add(this.label24);
            this.staffTabUpdate.Controls.Add(this.tel1Txt);
            this.staffTabUpdate.Controls.Add(this.label17);
            this.staffTabUpdate.Controls.Add(this.label18);
            this.staffTabUpdate.Controls.Add(this.nicTxt);
            this.staffTabUpdate.Controls.Add(this.label19);
            this.staffTabUpdate.Controls.Add(this.label20);
            this.staffTabUpdate.Controls.Add(this.ageTxt);
            this.staffTabUpdate.Controls.Add(this.label15);
            this.staffTabUpdate.Controls.Add(this.lnameTxt);
            this.staffTabUpdate.Controls.Add(this.label16);
            this.staffTabUpdate.Controls.Add(this.fnameTxt);
            this.staffTabUpdate.Controls.Add(this.label14);
            this.staffTabUpdate.Controls.Add(this.empIdTxt);
            this.staffTabUpdate.Controls.Add(this.label13);
            this.staffTabUpdate.HorizontalScrollbarBarColor = true;
            this.staffTabUpdate.HorizontalScrollbarHighlightOnWheel = false;
            this.staffTabUpdate.HorizontalScrollbarSize = 10;
            this.staffTabUpdate.Location = new System.Drawing.Point(4, 38);
            this.staffTabUpdate.Name = "staffTabUpdate";
            this.staffTabUpdate.Size = new System.Drawing.Size(847, 452);
            this.staffTabUpdate.TabIndex = 2;
            this.staffTabUpdate.Text = "Update";
            this.staffTabUpdate.VerticalScrollbarBarColor = true;
            this.staffTabUpdate.VerticalScrollbarHighlightOnWheel = false;
            this.staffTabUpdate.VerticalScrollbarSize = 10;
            this.staffTabUpdate.Click += new System.EventHandler(this.staffTabUpdate_Click);
            // 
            // comboBox1type
            // 
            this.comboBox1type.FormattingEnabled = true;
            this.comboBox1type.Items.AddRange(new object[] {
            "manager",
            "trainer",
            "instructor",
            "security",
            "junitor"});
            this.comboBox1type.Location = new System.Drawing.Point(124, 328);
            this.comboBox1type.Name = "comboBox1type";
            this.comboBox1type.Size = new System.Drawing.Size(121, 24);
            this.comboBox1type.TabIndex = 43;
            // 
            // dateTimePickerDOBS
            // 
            this.dateTimePickerDOBS.CustomFormat = "yyyy-MM-dd";
            this.dateTimePickerDOBS.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePickerDOBS.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePickerDOBS.Location = new System.Drawing.Point(124, 358);
            this.dateTimePickerDOBS.Name = "dateTimePickerDOBS";
            this.dateTimePickerDOBS.Size = new System.Drawing.Size(122, 24);
            this.dateTimePickerDOBS.TabIndex = 42;
            // 
            // dateTimePickerJOD
            // 
            this.dateTimePickerJOD.CustomFormat = "yyyy-MM-dd";
            this.dateTimePickerJOD.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePickerJOD.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePickerJOD.Location = new System.Drawing.Point(124, 390);
            this.dateTimePickerJOD.Name = "dateTimePickerJOD";
            this.dateTimePickerJOD.Size = new System.Drawing.Size(122, 24);
            this.dateTimePickerJOD.TabIndex = 41;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label30.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label30.Location = new System.Drawing.Point(5, 392);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(86, 20);
            this.label30.TabIndex = 39;
            this.label30.Text = "Joined date";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label31.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label31.Location = new System.Drawing.Point(5, 362);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(40, 20);
            this.label31.TabIndex = 37;
            this.label31.Text = "DOB";
            // 
            // rbFemale
            // 
            this.rbFemale.AutoSize = true;
            this.rbFemale.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.rbFemale.ForeColor = System.Drawing.SystemColors.ControlText;
            this.rbFemale.Location = new System.Drawing.Point(188, 266);
            this.rbFemale.Name = "rbFemale";
            this.rbFemale.Size = new System.Drawing.Size(71, 21);
            this.rbFemale.TabIndex = 36;
            this.rbFemale.TabStop = true;
            this.rbFemale.Text = "female";
            this.rbFemale.UseVisualStyleBackColor = false;
            // 
            // rbMale
            // 
            this.rbMale.AutoSize = true;
            this.rbMale.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.rbMale.ForeColor = System.Drawing.SystemColors.ControlText;
            this.rbMale.Location = new System.Drawing.Point(123, 266);
            this.rbMale.Name = "rbMale";
            this.rbMale.Size = new System.Drawing.Size(59, 21);
            this.rbMale.TabIndex = 35;
            this.rbMale.TabStop = true;
            this.rbMale.Text = "male";
            this.rbMale.UseVisualStyleBackColor = false;
            this.rbMale.CheckedChanged += new System.EventHandler(this.rbMale_CheckedChanged);
            // 
            // btnUpload
            // 
            this.btnUpload.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnUpload.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnUpload.Image = global::GymManagementSystem.Properties.Resources._2_050;
            this.btnUpload.Location = new System.Drawing.Point(141, 110);
            this.btnUpload.Name = "btnUpload";
            this.btnUpload.Size = new System.Drawing.Size(62, 41);
            this.btnUpload.TabIndex = 34;
            this.btnUpload.UseVisualStyleBackColor = false;
            this.btnUpload.Click += new System.EventHandler(this.btnUpload_Click);
            // 
            // buttonView
            // 
            this.buttonView.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.buttonView.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonView.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.buttonView.Image = global::GymManagementSystem.Properties.Resources.eye;
            this.buttonView.Location = new System.Drawing.Point(447, 172);
            this.buttonView.Name = "buttonView";
            this.buttonView.Size = new System.Drawing.Size(120, 43);
            this.buttonView.TabIndex = 33;
            this.buttonView.Text = "View";
            this.buttonView.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.buttonView.UseVisualStyleBackColor = false;
            this.buttonView.Click += new System.EventHandler(this.buttonView_Click);
            // 
            // buttonClear
            // 
            this.buttonClear.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.buttonClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonClear.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.buttonClear.Image = global::GymManagementSystem.Properties.Resources.edit_clear__1_;
            this.buttonClear.Location = new System.Drawing.Point(573, 172);
            this.buttonClear.Name = "buttonClear";
            this.buttonClear.Size = new System.Drawing.Size(120, 43);
            this.buttonClear.TabIndex = 32;
            this.buttonClear.Text = "Clear";
            this.buttonClear.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.buttonClear.UseVisualStyleBackColor = false;
            // 
            // buttonUpdate
            // 
            this.buttonUpdate.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.buttonUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonUpdate.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.buttonUpdate.Image = global::GymManagementSystem.Properties.Resources.update;
            this.buttonUpdate.Location = new System.Drawing.Point(699, 172);
            this.buttonUpdate.Name = "buttonUpdate";
            this.buttonUpdate.Size = new System.Drawing.Size(120, 43);
            this.buttonUpdate.TabIndex = 31;
            this.buttonUpdate.Text = "Update";
            this.buttonUpdate.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.buttonUpdate.UseVisualStyleBackColor = false;
            this.buttonUpdate.Click += new System.EventHandler(this.buttonUpdate_Click);
            // 
            // pictureBoxUpdate
            // 
            this.pictureBoxUpdate.Location = new System.Drawing.Point(46, 47);
            this.pictureBoxUpdate.Name = "pictureBoxUpdate";
            this.pictureBoxUpdate.Size = new System.Drawing.Size(128, 104);
            this.pictureBoxUpdate.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxUpdate.TabIndex = 29;
            this.pictureBoxUpdate.TabStop = false;
            this.pictureBoxUpdate.Click += new System.EventHandler(this.pictureBoxUpdate_Click);
            // 
            // dataGridView2updateStaff
            // 
            this.dataGridView2updateStaff.AllowUserToAddRows = false;
            this.dataGridView2updateStaff.AllowUserToDeleteRows = false;
            this.dataGridView2updateStaff.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2updateStaff.Location = new System.Drawing.Point(311, 220);
            this.dataGridView2updateStaff.Name = "dataGridView2updateStaff";
            this.dataGridView2updateStaff.ReadOnly = true;
            this.dataGridView2updateStaff.RowHeadersWidth = 51;
            this.dataGridView2updateStaff.RowTemplate.Height = 24;
            this.dataGridView2updateStaff.Size = new System.Drawing.Size(508, 215);
            this.dataGridView2updateStaff.TabIndex = 28;
            this.dataGridView2updateStaff.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2update);
            // 
            // addressTxt
            // 
            this.addressTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addressTxt.Location = new System.Drawing.Point(427, 72);
            this.addressTxt.Name = "addressTxt";
            this.addressTxt.Size = new System.Drawing.Size(266, 24);
            this.addressTxt.TabIndex = 27;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label25.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label25.Location = new System.Drawing.Point(307, 72);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(62, 20);
            this.label25.TabIndex = 26;
            this.label25.Text = "Address";
            // 
            // textBox9
            // 
            this.textBox9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox9.Location = new System.Drawing.Point(145, 470);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(100, 24);
            this.textBox9.TabIndex = 25;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label21.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label21.Location = new System.Drawing.Point(25, 470);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(58, 20);
            this.label21.TabIndex = 24;
            this.label21.Text = "label21";
            // 
            // faxTxt
            // 
            this.faxTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.faxTxt.Location = new System.Drawing.Point(427, 142);
            this.faxTxt.Name = "faxTxt";
            this.faxTxt.Size = new System.Drawing.Size(266, 24);
            this.faxTxt.TabIndex = 23;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label22.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label22.Location = new System.Drawing.Point(307, 142);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(30, 20);
            this.label22.TabIndex = 22;
            this.label22.Text = "Fax";
            // 
            // emailTxt
            // 
            this.emailTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.emailTxt.Location = new System.Drawing.Point(427, 108);
            this.emailTxt.Name = "emailTxt";
            this.emailTxt.Size = new System.Drawing.Size(266, 24);
            this.emailTxt.TabIndex = 21;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label23.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label23.Location = new System.Drawing.Point(307, 108);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(46, 20);
            this.label23.TabIndex = 20;
            this.label23.Text = "Email";
            // 
            // tel2Txt
            // 
            this.tel2Txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tel2Txt.Location = new System.Drawing.Point(427, 37);
            this.tel2Txt.Name = "tel2Txt";
            this.tel2Txt.Size = new System.Drawing.Size(123, 24);
            this.tel2Txt.TabIndex = 19;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label24.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label24.Location = new System.Drawing.Point(307, 37);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(90, 20);
            this.label24.TabIndex = 18;
            this.label24.Text = "Telephone 2";
            // 
            // tel1Txt
            // 
            this.tel1Txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tel1Txt.Location = new System.Drawing.Point(427, 3);
            this.tel1Txt.Name = "tel1Txt";
            this.tel1Txt.Size = new System.Drawing.Size(123, 24);
            this.tel1Txt.TabIndex = 17;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label17.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label17.Location = new System.Drawing.Point(307, 3);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(90, 20);
            this.label17.TabIndex = 16;
            this.label17.Text = "Telephone 1";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label18.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label18.Location = new System.Drawing.Point(5, 332);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(40, 20);
            this.label18.TabIndex = 14;
            this.label18.Text = "Type";
            this.label18.Click += new System.EventHandler(this.label18_Click);
            // 
            // nicTxt
            // 
            this.nicTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nicTxt.Location = new System.Drawing.Point(124, 295);
            this.nicTxt.Name = "nicTxt";
            this.nicTxt.Size = new System.Drawing.Size(123, 24);
            this.nicTxt.TabIndex = 13;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label19.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label19.Location = new System.Drawing.Point(4, 295);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(33, 20);
            this.label19.TabIndex = 12;
            this.label19.Text = "NIC";
            this.label19.Click += new System.EventHandler(this.label19_Click);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label20.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label20.Location = new System.Drawing.Point(3, 265);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(57, 20);
            this.label20.TabIndex = 10;
            this.label20.Text = "Gender";
            this.label20.Click += new System.EventHandler(this.label20_Click);
            // 
            // ageTxt
            // 
            this.ageTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ageTxt.Location = new System.Drawing.Point(124, 234);
            this.ageTxt.Name = "ageTxt";
            this.ageTxt.Size = new System.Drawing.Size(123, 24);
            this.ageTxt.TabIndex = 9;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label15.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label15.Location = new System.Drawing.Point(4, 234);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(36, 20);
            this.label15.TabIndex = 8;
            this.label15.Text = "Age";
            this.label15.Click += new System.EventHandler(this.label15_Click);
            // 
            // lnameTxt
            // 
            this.lnameTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnameTxt.Location = new System.Drawing.Point(123, 201);
            this.lnameTxt.Name = "lnameTxt";
            this.lnameTxt.Size = new System.Drawing.Size(123, 24);
            this.lnameTxt.TabIndex = 7;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label16.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label16.Location = new System.Drawing.Point(3, 201);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(79, 20);
            this.label16.TabIndex = 6;
            this.label16.Text = "Last Name";
            this.label16.Click += new System.EventHandler(this.label16_Click);
            // 
            // fnameTxt
            // 
            this.fnameTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fnameTxt.Location = new System.Drawing.Point(123, 167);
            this.fnameTxt.Name = "fnameTxt";
            this.fnameTxt.Size = new System.Drawing.Size(123, 24);
            this.fnameTxt.TabIndex = 5;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label14.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label14.Location = new System.Drawing.Point(3, 167);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(80, 20);
            this.label14.TabIndex = 4;
            this.label14.Text = "Frist Name";
            this.label14.Click += new System.EventHandler(this.label14_Click);
            // 
            // empIdTxt
            // 
            this.empIdTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.empIdTxt.Location = new System.Drawing.Point(167, 17);
            this.empIdTxt.Name = "empIdTxt";
            this.empIdTxt.Size = new System.Drawing.Size(100, 24);
            this.empIdTxt.TabIndex = 3;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label13.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label13.Location = new System.Drawing.Point(4, 21);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(157, 20);
            this.label13.TabIndex = 2;
            this.label13.Text = "Enter the employee ID";
            // 
            // staffTabView
            // 
            this.staffTabView.Controls.Add(this.btnView);
            this.staffTabView.Controls.Add(this.button2);
            this.staffTabView.Controls.Add(this.txt_search);
            this.staffTabView.Controls.Add(this.label27);
            this.staffTabView.Controls.Add(this.dataGridView3Search);
            this.staffTabView.HorizontalScrollbarBarColor = true;
            this.staffTabView.HorizontalScrollbarHighlightOnWheel = false;
            this.staffTabView.HorizontalScrollbarSize = 10;
            this.staffTabView.Location = new System.Drawing.Point(4, 38);
            this.staffTabView.Name = "staffTabView";
            this.staffTabView.Size = new System.Drawing.Size(847, 452);
            this.staffTabView.TabIndex = 3;
            this.staffTabView.Text = "Veiw";
            this.staffTabView.VerticalScrollbarBarColor = true;
            this.staffTabView.VerticalScrollbarHighlightOnWheel = false;
            this.staffTabView.VerticalScrollbarSize = 10;
            // 
            // btnView
            // 
            this.btnView.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnView.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnView.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnView.Location = new System.Drawing.Point(14, 400);
            this.btnView.Name = "btnView";
            this.btnView.Size = new System.Drawing.Size(99, 35);
            this.btnView.TabIndex = 49;
            this.btnView.Text = "View";
            this.btnView.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnView.UseVisualStyleBackColor = false;
            this.btnView.Click += new System.EventHandler(this.btnView_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button2.Location = new System.Drawing.Point(236, 18);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(74, 35);
            this.button2.TabIndex = 48;
            this.button2.Text = "select";
            this.button2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // txt_search
            // 
            this.txt_search.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_search.Location = new System.Drawing.Point(130, 23);
            this.txt_search.Name = "txt_search";
            this.txt_search.Size = new System.Drawing.Size(100, 24);
            this.txt_search.TabIndex = 47;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label27.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label27.Location = new System.Drawing.Point(17, 27);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(94, 20);
            this.label27.TabIndex = 46;
            this.label27.Text = "Employee ID";
            // 
            // dataGridView3Search
            // 
            this.dataGridView3Search.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3Search.Location = new System.Drawing.Point(14, 69);
            this.dataGridView3Search.Name = "dataGridView3Search";
            this.dataGridView3Search.RowHeadersWidth = 51;
            this.dataGridView3Search.RowTemplate.Height = 24;
            this.dataGridView3Search.Size = new System.Drawing.Size(818, 325);
            this.dataGridView3Search.TabIndex = 45;
            // 
            // frmStaff
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(899, 560);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.staffTabPanel);
            this.Name = "frmStaff";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmStaff";
            this.staffTabPanel.ResumeLayout(false);
            this.staffTabAdd.ResumeLayout(false);
            this.staffTabAdd.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxProfile)).EndInit();
            this.staffTabDelete.ResumeLayout(false);
            this.staffTabDelete.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1staff)).EndInit();
            this.staffTabUpdate.ResumeLayout(false);
            this.staffTabUpdate.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxUpdate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2updateStaff)).EndInit();
            this.staffTabView.ResumeLayout(false);
            this.staffTabView.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3Search)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label26;
        private MetroFramework.Controls.MetroTabControl staffTabPanel;
        private MetroFramework.Controls.MetroTabPage staffTabAdd;
        private System.Windows.Forms.DateTimePicker dateTimePickerDOB;
        private System.Windows.Forms.DateTimePicker dateTimePickerJoinDate;
        private System.Windows.Forms.ComboBox comboBoxType;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox txt_empId;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.RadioButton radioButtonFemale;
        private System.Windows.Forms.RadioButton radioButtonMale;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnBrowse;
        private System.Windows.Forms.TextBox txtNIC;
        private System.Windows.Forms.TextBox txtAge;
        private System.Windows.Forms.TextBox txtLName;
        private System.Windows.Forms.TextBox txtFname;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtPhoneTwo;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.TextBox txtFax;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.TextBox txtPhoneOne;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.PictureBox picBoxProfile;
        private MetroFramework.Controls.MetroTabPage staffTabDelete;
        private System.Windows.Forms.Button btnClear2;
        private System.Windows.Forms.Button buttonShow;
        private System.Windows.Forms.DataGridView dataGridView1staff;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.TextBox txtEmpId;
        private System.Windows.Forms.Label lblMemberId;
        private MetroFramework.Controls.MetroTabPage staffTabUpdate;
        private System.Windows.Forms.RadioButton rbFemale;
        private System.Windows.Forms.RadioButton rbMale;
        private System.Windows.Forms.Button btnUpload;
        private System.Windows.Forms.Button buttonView;
        private System.Windows.Forms.Button buttonClear;
        private System.Windows.Forms.Button buttonUpdate;
        private System.Windows.Forms.PictureBox pictureBoxUpdate;
        private System.Windows.Forms.DataGridView dataGridView2updateStaff;
        private System.Windows.Forms.TextBox addressTxt;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox faxTxt;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox emailTxt;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox tel2Txt;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox tel1Txt;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox nicTxt;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox ageTxt;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox lnameTxt;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox fnameTxt;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox empIdTxt;
        private System.Windows.Forms.Label label13;
        private MetroFramework.Controls.MetroTabPage staffTabView;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.ComboBox comboBox1type;
        private System.Windows.Forms.DateTimePicker dateTimePickerDOBS;
        private System.Windows.Forms.DateTimePicker dateTimePickerJOD;
        private System.Windows.Forms.Button btnView;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox txt_search;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.DataGridView dataGridView3Search;
    }
}