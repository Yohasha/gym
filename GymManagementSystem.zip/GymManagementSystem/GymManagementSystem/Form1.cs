﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace GymManagementSystem
{
    public partial class Form1 : Form
    {
        MySqlConnection con = new MySqlConnection("server=localhost;database=gms;username=root;password=");
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_Login_Click(object sender, EventArgs e)
        {
            //11, 7, 30
            //32, 30, 45
            con.Open();

            MySqlCommand cmd = new MySqlCommand("select username,password  from login  where username='" + txt_Username.Text + "'and password='" + txt_Password.Text + "'", con);
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                this.Hide();
                formHome fm = new formHome();
              //  frm_Dashboard fm = new frm_Dashboard();
                fm.Show();
            }
            else
            {
                MessageBox.Show("Invalid Login please check username and password");
            }
            con.Close();
        }

        private void lbl_Exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void passwordEnter(object sender, EventArgs e)
        {
            if (txt_Password.Text == "password")
            {
                txt_Password.Text = "";
                txt_Password.ForeColor = Color.Black;
            }
        }

        private void passwordLeave(object sender, EventArgs e)
        {
            if (txt_Password.Text == "")
            {
                txt_Password.Text = "password";
                txt_Password.ForeColor = Color.Silver;
            }
        }

        private void usernameEnter(object sender, EventArgs e)
        {
            if (txt_Username.Text == "Username")
            {
                txt_Username.Text = "";
                txt_Username.ForeColor = Color.Black;
            }
        }

        private void usernameLeave(object sender, EventArgs e)
        {
            if (txt_Username.Text == "")
            {
                txt_Username.Text = "Username";
                txt_Username.ForeColor = Color.Silver;
            }
        }

        private void checkBoxShow_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxShow.Checked)
            {
                txt_Password.UseSystemPasswordChar = false;
            }
            else
            {
                txt_Password.UseSystemPasswordChar = true;
            }
        }
    
    }
}
