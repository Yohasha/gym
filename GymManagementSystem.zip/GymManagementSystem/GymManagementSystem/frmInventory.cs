﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace GymManagementSystem
{
    public partial class frmInventory : Form
    {
        MySqlConnection con = new MySqlConnection("server=localhost;database=gms;username=root;password=");

        public frmInventory()
        {
            InitializeComponent();
        }
        public void fillData()
        {
            try
            {

                con.Open();
                MySqlCommand cmd = new MySqlCommand("SELECT * FROM inventory", con);
                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridViewInventory.DataSource = dt;
                con.Close();
            }
            catch (Exception ex) { }

        }
        

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                MemoryStream ms = new MemoryStream();
                picBoxProfile.Image.Save(ms, picBoxProfile.Image.RawFormat);
                byte[] img = ms.ToArray();

                MySqlCommand cmd = new MySqlCommand("INSERT INTO inventory VALUES('" + txt_ItemNo.Text + "','" + textBoxItemName.Text + "','" + textBoxDescription.Text + "','" + comboBoxComName.Text + "'," + textBoxAmount.Text + ",@img)", con);

                cmd.Parameters.Add("@img", MySqlDbType.LongBlob);

                cmd.Parameters["@img"].Value = img;

                if (cmd.ExecuteNonQuery() == 1)
                {

                    MessageBox.Show("data insert");
                }
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }


            //   MySqlCommand cmd = new MySqlCommand("INSERT INTO inventory VALUES('" + txt_empId.Text + "','" + textBoxItemName.Text + "','" + textBoxDescription.Text + "','" + comboBoxComName.Text + "'," + textBoxAmount.Text + ",null)", con);



        }

        private void button4_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "png files(*.png)|*.png|jpg files(*.jpg)|*.jpg|All files(*.*)|*.*";
            if (dialog.ShowDialog() == DialogResult.OK)
            {

                picBoxProfile.Image = Image.FromFile(dialog.FileName);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                MySqlCommand cmd = new MySqlCommand("DELETE FROM inventory WHERE itemNo = '" + txt_ItemNo.Text + "'", con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("item is removed Thank you..");
                con.Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();

                MemoryStream ms = new MemoryStream();
                picBoxProfile.Image.Save(ms, picBoxProfile.Image.RawFormat);
                byte[] img = ms.ToArray();

                MySqlCommand cmd = new MySqlCommand("UPDATE inventory SET itemName='" + textBoxItemName.Text + "',description='" + textBoxDescription.Text + "',company='" + comboBoxComName.Text + "',amount='" + textBoxAmount + "',itemImage= @img WHERE itemNo = '" + txt_ItemNo.Text + "'", con);



                cmd.Parameters.Add("@img", MySqlDbType.LongBlob);

                cmd.Parameters["@img"].Value = img;

                if (cmd.ExecuteNonQuery() == 1)
                { 

                    MessageBox.Show("data update Thank you ! ");
                }
                con.Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }


            //MySqlCommand cmd = new MySqlCommand("UPDATE inventory SET itemName='" + textBoxItemName.Text + "',description='" + textBoxDescription.Text + "',company='" + comboBoxComName.Text + "',amount='" + textBoxAmount + "',itemImage= @img WHERE itemNo = '" + txt_ItemNo.Text + "'", con);

        }

        private void buttonView_Click(object sender, EventArgs e)
        {
            fillData();
        }

        private void cellClick(object sender, DataGridViewCellEventArgs e)
        {
            dataGridViewInventory.CurrentRow.Selected = true;

            txt_ItemNo.Text = dataGridViewInventory.Rows[e.RowIndex].Cells["itemNO"].Value.ToString();
            textBoxItemName.Text = dataGridViewInventory.Rows[e.RowIndex].Cells["itemName"].Value.ToString();
            textBoxDescription.Text = dataGridViewInventory.Rows[e.RowIndex].Cells["description"].Value.ToString();
            comboBoxComName.Text = dataGridViewInventory.Rows[e.RowIndex].Cells["company"].Value.ToString();
            textBoxAmount.Text = dataGridViewInventory.Rows[e.RowIndex].Cells["amount"].Value.ToString();
           
            Byte[] image = Encoding.ASCII.GetBytes(dataGridViewInventory.SelectedRows[0].Cells["itemImage"].Value.ToString());

            if (image == null)
            {
                picBoxProfile.Image = null;
            }
            else
            {
                var DATA = (Byte[])(dataGridViewInventory.SelectedRows[0].Cells["itemImage"].Value);
                var stream = new MemoryStream(DATA);
                picBoxProfile.Image = Image.FromStream(stream);
            }
           
        }
    }
}
