﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GymManagementSystem
{
    public partial class frm_Dashboard : Form
    {
        public frm_Dashboard()
        {
            InitializeComponent();
        }

        private void btn_member_Click(object sender, EventArgs e)
        {
            this.Hide();
            member fm = new member();
            fm.Show();
        }

        private void btn_staff_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmStaff fs = new frmStaff();
            fs.Show();
        }

        private void metroButton9_Click(object sender, EventArgs e)
        {
          // member.MPageAdd t1m = new MPageAdd();

        }
    }
}
