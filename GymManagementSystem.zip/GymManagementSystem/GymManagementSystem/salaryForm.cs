﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace GymManagementSystem
{
    public partial class salaryForm : Form
    {
        MySqlConnection con = new MySqlConnection("server=localhost;database=gms;username=root;password=");
        MySqlCommand cmd;
        MySqlDataReader mdr;
        public salaryForm()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
        double basicSalary;
        String type;
        private void button1_Click(object sender, EventArgs e)
        {
   
            double totalSalary, leave, leaveDeduction, travelAllownce, medicalAllownce, bonus;
            buttonPrint.Enabled = true;

            label1.Text = DateTime.Now.ToLongDateString();
            label2.Text = DateTime.Now.ToLongTimeString();

            basicSalary = Double.Parse(txtBasicPay.Text);
            bonus = Double.Parse(txtBonus.Text);
          //  leaveDeduction = Double.Parse(textBoxDeduction.Text);
           
            travelAllownce = Double.Parse(textBoxTravel.Text);
            medicalAllownce = Double.Parse(textBoxMedical.Text);
            type = labelType.Text;
            

            if (type == "manager")
            { basicSalary = 40000;
            }
            else if (type == "trainer")
            {
                basicSalary = 30000;
            }
            else if (type == "instructor")
            {
                basicSalary = 35000;
            }
            else if (type == "security")
            { basicSalary = 20000; }
            else if (type == "junitor")
            { basicSalary = 10000; }

            leave = Double.Parse(textBoxLeave.Text);

            if (leave <= 3)
            {
                leaveDeduction = 0;
            }
            else
            {
                leaveDeduction = leave * 300;
            }

       

            totalSalary = ((basicSalary + bonus + medicalAllownce + travelAllownce ) - leaveDeduction) ;

            labelDeduction.Text = leaveDeduction.ToString();
            labelTotalSalary.Text = totalSalary.ToString();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void salaryForm_Load(object sender, EventArgs e)
        {

        }

        private void buttonSelect_Click(object sender, EventArgs e)
        {


            buttonGenerate.Enabled = true;

            con.Open();

            

            string selectQuery = "SELECT * FROM staff  WHERE emp_id='" + txt_empId.Text + "'";
            cmd = new MySqlCommand(selectQuery, con);

            mdr = cmd.ExecuteReader();

            if(mdr.Read())
            {
                labelEmpId.Text = mdr.GetString("emp_id");
                labelFname.Text = mdr.GetString("first_name");
                labelLname.Text = mdr.GetString("last_name");
               labelType.Text = mdr.GetString("type");
              

            }
            con.Close();

            type = labelType.Text;
            if (type == "manager")
            {
                basicSalary = 40000;
            }
            else if (type == "trainer")
            {
                basicSalary = 30000;
            }
            else if (type == "instructor")
            {
                basicSalary = 35000;
            }
            else if (type == "security")
            { basicSalary = 20000; }
            else if (type == "junitor")
            { basicSalary = 10000; }

            //MessageBox.Show("salary" + basicSalary);
            txtBasicPay.Text = basicSalary.ToString();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            printPreviewDialog1.Document = printDocument1;
            printPreviewDialog1.ShowDialog();
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
        //    Bitmap bmp = Properties.Resources.output_onlinepngtools__1_;
          //   Image newImage = bmp;
           //  e.Graphics.DrawImage(newImage, 30, 70, newImage.Width, newImage.Height);
            e.Graphics.DrawString("Gym managment system", new System.Drawing.Font("Arial", 26, FontStyle.Bold), Brushes.Black, new System.Drawing.Point(200,50));
            e.Graphics.DrawString(textBoxYear.Text+" year, " +comboBoxMonth.Text +" month payment sheet", new System.Drawing.Font("Arial", 10, FontStyle.Bold), Brushes.Black, new System.Drawing.Point(50, 200));

            e.Graphics.DrawString("Time", new System.Drawing.Font("Arial", 12, FontStyle.Regular), Brushes.Gray, new System.Drawing.Point(50, 250));
            e.Graphics.DrawString("Date", new System.Drawing.Font("Arial", 12, FontStyle.Regular), Brushes.Gray, new System.Drawing.Point(50, 280));
            e.Graphics.DrawString(labelDash.Text, new System.Drawing.Font("Arial", 12, FontStyle.Regular), Brushes.Gray, new System.Drawing.Point(30, 310));

            e.Graphics.DrawString("First Name", new System.Drawing.Font("Arial", 12, FontStyle.Regular), Brushes.Gray, new System.Drawing.Point(50, 350));
            e.Graphics.DrawString("Last Name", new System.Drawing.Font("Arial", 12, FontStyle.Regular), Brushes.Gray, new System.Drawing.Point(50, 380));
            e.Graphics.DrawString(labelDash.Text, new System.Drawing.Font("Arial", 12, FontStyle.Regular), Brushes.Gray, new System.Drawing.Point(30, 410));

            e.Graphics.DrawString("leaves", new System.Drawing.Font("Arial", 12, FontStyle.Regular), Brushes.Gray, new System.Drawing.Point(50, 450));
            e.Graphics.DrawString("Approval leave", new System.Drawing.Font("Arial", 12, FontStyle.Regular), Brushes.Gray, new System.Drawing.Point(50, 480));
            e.Graphics.DrawString("Leave deduction", new System.Drawing.Font("Arial", 12, FontStyle.Regular), Brushes.Gray, new System.Drawing.Point(50, 510));
            e.Graphics.DrawString(labelDash.Text, new System.Drawing.Font("Arial", 12, FontStyle.Regular), Brushes.Gray, new System.Drawing.Point(30, 540));

            e.Graphics.DrawString("Travel Allownce", new System.Drawing.Font("Arial", 12, FontStyle.Regular), Brushes.Gray, new System.Drawing.Point(50, 580));
            e.Graphics.DrawString("Health Allownce", new System.Drawing.Font("Arial", 12, FontStyle.Regular), Brushes.Gray, new System.Drawing.Point(50, 610));
            e.Graphics.DrawString("Bonus", new System.Drawing.Font("Arial", 12, FontStyle.Regular), Brushes.Gray, new System.Drawing.Point(50, 640));
            e.Graphics.DrawString(labelDash.Text, new System.Drawing.Font("Arial", 12, FontStyle.Regular), Brushes.Gray, new System.Drawing.Point(30, 670));

            e.Graphics.DrawString("Basic Salary", new System.Drawing.Font("Arial", 12, FontStyle.Regular), Brushes.Gray, new System.Drawing.Point(50, 710));
            e.Graphics.DrawString(labelDash.Text, new System.Drawing.Font("Arial", 12, FontStyle.Regular), Brushes.Gray, new System.Drawing.Point(30, 740));

            e.Graphics.DrawString("Total Salary", new System.Drawing.Font("Arial", 12, FontStyle.Regular), Brushes.Gray, new System.Drawing.Point(50, 780));




            // bill Values
            e.Graphics.DrawString( label2.Text, new System.Drawing.Font("Arial", 12, FontStyle.Regular), Brushes.Gray, new System.Drawing.Point(350, 250));
            e.Graphics.DrawString(label1.Text, new System.Drawing.Font("Arial", 12, FontStyle.Regular), Brushes.Gray, new System.Drawing.Point(350, 280));
           
            e.Graphics.DrawString("RS." + labelFname.Text, new System.Drawing.Font("Arial", 12, FontStyle.Regular), Brushes.Gray, new System.Drawing.Point(350, 350));
            e.Graphics.DrawString("RS." + labelLname.Text, new System.Drawing.Font("Arial", 12, FontStyle.Regular), Brushes.Gray, new System.Drawing.Point(350, 380));
            
            e.Graphics.DrawString("RS." + textBoxLeave.Text,new System.Drawing.Font("Arial", 12, FontStyle.Regular), Brushes.Gray, new System.Drawing.Point(350, 450));
            e.Graphics.DrawString("RS." + textBoxApproveLeave.Text, new System.Drawing.Font("Arial", 12, FontStyle.Regular), Brushes.Gray, new System.Drawing.Point(350, 480));
            e.Graphics.DrawString("RS." + labelDeduction.Text, new System.Drawing.Font("Arial", 12, FontStyle.Regular), Brushes.Gray, new System.Drawing.Point(350, 510));
            
            e.Graphics.DrawString("RS." + textBoxTravel.Text, new System.Drawing.Font("Arial", 12, FontStyle.Regular), Brushes.Gray, new System.Drawing.Point(350, 580));
            e.Graphics.DrawString("RS." + textBoxMedical.Text, new System.Drawing.Font("Arial", 12, FontStyle.Regular), Brushes.Gray, new System.Drawing.Point(350, 610));
            e.Graphics.DrawString("RS." + txtBonus.Text, new System.Drawing.Font("Arial", 12, FontStyle.Regular), Brushes.Gray, new System.Drawing.Point(350, 640));
            
            e.Graphics.DrawString("RS." + txtBasicPay.Text, new System.Drawing.Font("Arial", 12, FontStyle.Regular), Brushes.Gray, new System.Drawing.Point(350, 710));
           
            e.Graphics.DrawString("RS." + labelTotalSalary.Text, new System.Drawing.Font("Arial", 12, FontStyle.Regular), Brushes.Gray, new System.Drawing.Point(350, 780));

           
        }
    }
}
