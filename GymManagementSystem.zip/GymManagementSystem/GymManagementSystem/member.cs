﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace GymManagementSystem
{
    public partial class member : Form
    {
        MySqlConnection con = new MySqlConnection("server=localhost;database=gms;username=root;password=");
        String Gender;
        MySqlDataAdapter adapter;
        MySqlCommand cmd;
        DataTable dt = new DataTable();
        
        public member()
        {
            InitializeComponent();
           
           
            dataGridView1member.MultiSelect = false;
        }
        public void fillData()
        {
            try
            {

                con.Open();
                MySqlCommand cmd = new MySqlCommand("SELECT * FROM members", con);
                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1member.DataSource = dt;
                con.Close();
            }
            catch (Exception ex) { }

        }

        public void fillDataUpadated()
        {
            try
            {

                con.Open();
                MySqlCommand cmd = new MySqlCommand("SELECT * FROM members", con);
                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView2update.DataSource = dt;
                con.Close();
            }
            catch (Exception ex) { }

        }



        private void lbl_Exit_Click(object sender, EventArgs e)
        {
            this.Close();

           
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {

            try
            {
                con.Open();

                MemoryStream ms = new MemoryStream();
                picBoxProfile.Image.Save(ms, picBoxProfile.Image.RawFormat);
                byte[] img = ms.ToArray();

                if (radioButtonMale.Checked)
                {
                    Gender = "male";
                }
                if (radioButtonFemale.Checked)
                {
                    Gender = "female";
                }
                MySqlCommand cmd = new MySqlCommand("INSERT INTO members VALUES('"+txt_memId.Text+"','" + txtFname.Text + "','" + txtLName.Text + "','" + txtAge.Text + "','" + Gender + "','" + txtNIC.Text + "','" + txtFee.Text + "','" + txtPhoneOne.Text + "','" + txtPhoneTwo.Text + "','" + txtAddress.Text + "','" + txtEmail.Text + "','" + txtFax.Text + "',@img)", con);
               
                cmd.Parameters.Add("@img", MySqlDbType.LongBlob);

                cmd.Parameters["@img"].Value = img;

                if (cmd.ExecuteNonQuery() == 1)
                {
                    
                    MessageBox.Show("data insert");
                }
                con.Close();
            }
            catch (Exception ex) {
                MessageBox.Show(ex.Message);
            }


           fillData();
           fillDataUpadated();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtLName.Clear();
            txtFname.Clear();
            txtAge.Clear();
            txtFee.Clear();
            txtNIC.Clear();
            txtPhoneOne.Clear();
            txtPhoneTwo.Clear();
            txtEmail.Clear();
            txtAddress.Clear();
            txtFax.Clear();
            radioButtonFemale.Checked = false;
            radioButtonMale.Checked = false;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "png files(*.png)|*.png|jpg files(*.jpg)|*.jpg|All files(*.*)|*.*";
            if (dialog.ShowDialog() == DialogResult.OK)
            {
              
                picBoxProfile.Image = Image.FromFile(dialog.FileName);
            }
        }

        private void buttonShow_Click(object sender, EventArgs e)
        {
            fillData();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            txtMemId.Clear();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                    con.Open();
                    MySqlCommand cmd = new MySqlCommand("DELETE FROM members WHERE ID='" + txtMemId.Text + "'", con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Member is removed Thank you..");
                    con.Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
            fillData();
            fillDataUpadated();
        }

        private void btnUpload_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "png files(*.png)|*.png|jpg files(*.jpg)|*.jpg|All files(*.*)|*.*";
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                pictureBoxUpdate.Image = Image.FromFile(dialog.FileName);
            }
        }

        private void buttonView_Click(object sender, EventArgs e)
        {
            fillDataUpadated();
        }

        private void dataGridView2update_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            dataGridView2update.CurrentRow.Selected = true;

            memberIdTxt.Text = dataGridView2update.Rows[e.RowIndex].Cells["id"].Value.ToString();
            fnameTxt.Text = dataGridView2update.Rows[e.RowIndex].Cells["first_name"].Value.ToString();
            lnameTxt.Text = dataGridView2update.Rows[e.RowIndex].Cells["last_name"].Value.ToString();
            ageTxt.Text = dataGridView2update.Rows[e.RowIndex].Cells["age"].Value.ToString();
            feeTxt.Text = dataGridView2update.Rows[e.RowIndex].Cells["fee"].Value.ToString();
            nicTxt.Text = dataGridView2update.Rows[e.RowIndex].Cells["NIC"].Value.ToString();
            tel1Txt.Text = dataGridView2update.Rows[e.RowIndex].Cells["phoneOne"].Value.ToString();
            tel2Txt.Text = dataGridView2update.Rows[e.RowIndex].Cells["phoneTwo"].Value.ToString();
            addressTxt.Text = dataGridView2update.Rows[e.RowIndex].Cells["address"].Value.ToString();
            emailTxt.Text = dataGridView2update.Rows[e.RowIndex].Cells["email"].Value.ToString();
            faxTxt.Text = dataGridView2update.Rows[e.RowIndex].Cells["fax"].Value.ToString();

            Byte[] image = Encoding.ASCII.GetBytes(dataGridView2update.SelectedRows[0].Cells["image"].Value.ToString());

            if (image == null)
            {
                pictureBoxUpdate.Image = null;
            }
            else  
            {
                var DATA = (Byte[])(dataGridView2update.SelectedRows[0].Cells["image"].Value);
                var stream = new MemoryStream(DATA);
                pictureBoxUpdate.Image = Image.FromStream(stream);
            }
            if(dataGridView2update.Rows[e.RowIndex].Cells["gender"].Value.ToString() == "female")
            {
                rbFemale.Checked = true;
            }
            if (dataGridView2update.Rows[e.RowIndex].Cells["gender"].Value.ToString() == "male")
            {
                rbMale.Checked = true;
            }
         
        }

        private void buttonUpdate_Click(object sender, EventArgs e)
        {
          
            
            try
            {
                con.Open();

                MemoryStream ms = new MemoryStream();
                pictureBoxUpdate.Image.Save(ms, pictureBoxUpdate.Image.RawFormat);
                byte[] img = ms.ToArray();

                if (radioButtonMale.Checked)
                {
                    Gender = "male";
                }
                if (radioButtonFemale.Checked)
                {
                    Gender = "female";
                }
                MySqlCommand cmd = new MySqlCommand("UPDATE members SET first_name='" + fnameTxt.Text + "',last_name='" + lnameTxt.Text + "',age='" + ageTxt.Text + "',gender='" + Gender + "',NIC='" + nicTxt.Text + "',fee='" + feeTxt.Text + "',phoneOne='" + tel1Txt.Text + "',phoneTwo='" + tel2Txt.Text + "',address='" + addressTxt.Text + "',email='" + emailTxt.Text + "',fax='" + faxTxt.Text + "',image= @img WHERE id='" + memberIdTxt.Text + "'", con);
             

                cmd.Parameters.Add("@img", MySqlDbType.LongBlob);

                cmd.Parameters["@img"].Value = img;

                if (cmd.ExecuteNonQuery() == 1)
                {

                    MessageBox.Show("data update Thank you ! ");
                }
                con.Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }

           fillData();
           fillDataUpadated();


        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            memberIdTxt.Clear();
            fnameTxt.Clear();
            lnameTxt.Clear();
            ageTxt.Clear();
            feeTxt.Clear();
            nicTxt.Clear();
            tel1Txt.Clear();
            tel2Txt.Clear();
            addressTxt.Clear();
            faxTxt.Clear();
            emailTxt.Clear();
            rbFemale.Checked = false;
            rbMale.Checked = false;
            pictureBoxUpdate.Image = null;


        }

        private void dataGridView1member_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            dataGridView1member.CurrentRow.Selected = true;

            txtMemId.Text = dataGridView1member.Rows[e.RowIndex].Cells["id"].Value.ToString();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            frm_Dashboard fd = new frm_Dashboard();
            fd.Show();
        }

        private void btnView_Click(object sender, EventArgs e)
        {
            try
            {

                con.Open();
                MySqlCommand cmd = new MySqlCommand("SELECT * FROM members", con);
                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView3Search.DataSource = dt;
                con.Close();
            }
            catch (Exception ex) { }
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            try
            {

                con.Open();
                MySqlCommand cmd = new MySqlCommand("SELECT * FROM members WHERE id='" + txt_search.Text + "'" , con);
                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView3Search.DataSource = dt;
                con.Close();
            }
            catch (Exception ex) { }
        }
    }
}
