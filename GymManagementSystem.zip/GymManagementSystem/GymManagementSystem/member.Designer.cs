﻿
namespace GymManagementSystem
{
    partial class member
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.MemberTabBox = new MetroFramework.Controls.MetroTabControl();
            this.MPageAdd = new MetroFramework.Controls.MetroTabPage();
            this.txt_memId = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.radioButtonFemale = new System.Windows.Forms.RadioButton();
            this.radioButtonMale = new System.Windows.Forms.RadioButton();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnBrowse = new System.Windows.Forms.Button();
            this.txtNIC = new System.Windows.Forms.TextBox();
            this.txtFee = new System.Windows.Forms.TextBox();
            this.txtAge = new System.Windows.Forms.TextBox();
            this.txtLName = new System.Windows.Forms.TextBox();
            this.txtFname = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtPhoneTwo = new System.Windows.Forms.TextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.txtFax = new System.Windows.Forms.TextBox();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.txtPhoneOne = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.picBoxProfile = new System.Windows.Forms.PictureBox();
            this.MPageDelete = new MetroFramework.Controls.MetroTabPage();
            this.dataGridView1member = new System.Windows.Forms.DataGridView();
            this.txtMemId = new System.Windows.Forms.TextBox();
            this.lblMemberId = new System.Windows.Forms.Label();
            this.btnClear2 = new System.Windows.Forms.Button();
            this.buttonShow = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.MPageUpdate = new MetroFramework.Controls.MetroTabPage();
            this.rbFemale = new System.Windows.Forms.RadioButton();
            this.rbMale = new System.Windows.Forms.RadioButton();
            this.dataGridView2update = new System.Windows.Forms.DataGridView();
            this.addressTxt = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.faxTxt = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.emailTxt = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.tel2Txt = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.tel1Txt = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.feeTxt = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.nicTxt = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.ageTxt = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.lnameTxt = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.fnameTxt = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.memberIdTxt = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.btnUpload = new System.Windows.Forms.Button();
            this.buttonView = new System.Windows.Forms.Button();
            this.buttonClear = new System.Windows.Forms.Button();
            this.buttonUpdate = new System.Windows.Forms.Button();
            this.pictureBoxUpdate = new System.Windows.Forms.PictureBox();
            this.MPageView = new MetroFramework.Controls.MetroTabPage();
            this.txt_search = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.dataGridView3Search = new System.Windows.Forms.DataGridView();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label26 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.btnView = new System.Windows.Forms.Button();
            this.MemberTabBox.SuspendLayout();
            this.MPageAdd.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxProfile)).BeginInit();
            this.MPageDelete.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1member)).BeginInit();
            this.MPageUpdate.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2update)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxUpdate)).BeginInit();
            this.MPageView.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3Search)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // MemberTabBox
            // 
            this.MemberTabBox.Controls.Add(this.MPageAdd);
            this.MemberTabBox.Controls.Add(this.MPageDelete);
            this.MemberTabBox.Controls.Add(this.MPageUpdate);
            this.MemberTabBox.Controls.Add(this.MPageView);
            this.MemberTabBox.Location = new System.Drawing.Point(30, 56);
            this.MemberTabBox.Name = "MemberTabBox";
            this.MemberTabBox.SelectedIndex = 3;
            this.MemberTabBox.Size = new System.Drawing.Size(844, 485);
            this.MemberTabBox.TabIndex = 0;
            this.MemberTabBox.Theme = MetroFramework.MetroThemeStyle.Light;
            this.MemberTabBox.UseSelectable = true;
            this.MemberTabBox.UseStyleColors = true;
            // 
            // MPageAdd
            // 
            this.MPageAdd.Controls.Add(this.txt_memId);
            this.MPageAdd.Controls.Add(this.label12);
            this.MPageAdd.Controls.Add(this.radioButtonFemale);
            this.MPageAdd.Controls.Add(this.radioButtonMale);
            this.MPageAdd.Controls.Add(this.btnExit);
            this.MPageAdd.Controls.Add(this.btnClear);
            this.MPageAdd.Controls.Add(this.btnAdd);
            this.MPageAdd.Controls.Add(this.btnBrowse);
            this.MPageAdd.Controls.Add(this.txtNIC);
            this.MPageAdd.Controls.Add(this.txtFee);
            this.MPageAdd.Controls.Add(this.txtAge);
            this.MPageAdd.Controls.Add(this.txtLName);
            this.MPageAdd.Controls.Add(this.txtFname);
            this.MPageAdd.Controls.Add(this.label5);
            this.MPageAdd.Controls.Add(this.label6);
            this.MPageAdd.Controls.Add(this.label3);
            this.MPageAdd.Controls.Add(this.label4);
            this.MPageAdd.Controls.Add(this.label2);
            this.MPageAdd.Controls.Add(this.label1);
            this.MPageAdd.Controls.Add(this.groupBox1);
            this.MPageAdd.Controls.Add(this.picBoxProfile);
            this.MPageAdd.HorizontalScrollbarBarColor = true;
            this.MPageAdd.HorizontalScrollbarHighlightOnWheel = false;
            this.MPageAdd.HorizontalScrollbarSize = 10;
            this.MPageAdd.Location = new System.Drawing.Point(4, 38);
            this.MPageAdd.Name = "MPageAdd";
            this.MPageAdd.Size = new System.Drawing.Size(836, 443);
            this.MPageAdd.TabIndex = 0;
            this.MPageAdd.Text = "Add";
            this.MPageAdd.VerticalScrollbarBarColor = true;
            this.MPageAdd.VerticalScrollbarHighlightOnWheel = false;
            this.MPageAdd.VerticalScrollbarSize = 10;
            // 
            // txt_memId
            // 
            this.txt_memId.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_memId.Location = new System.Drawing.Point(124, 18);
            this.txt_memId.Name = "txt_memId";
            this.txt_memId.Size = new System.Drawing.Size(132, 24);
            this.txt_memId.TabIndex = 40;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label12.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(27, 22);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(84, 20);
            this.label12.TabIndex = 39;
            this.label12.Text = "Member ID";
            // 
            // radioButtonFemale
            // 
            this.radioButtonFemale.AutoSize = true;
            this.radioButtonFemale.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.radioButtonFemale.Location = new System.Drawing.Point(458, 105);
            this.radioButtonFemale.Name = "radioButtonFemale";
            this.radioButtonFemale.Size = new System.Drawing.Size(75, 21);
            this.radioButtonFemale.TabIndex = 38;
            this.radioButtonFemale.TabStop = true;
            this.radioButtonFemale.Text = "Female";
            this.radioButtonFemale.UseVisualStyleBackColor = false;
            // 
            // radioButtonMale
            // 
            this.radioButtonMale.AutoSize = true;
            this.radioButtonMale.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.radioButtonMale.Location = new System.Drawing.Point(385, 104);
            this.radioButtonMale.Name = "radioButtonMale";
            this.radioButtonMale.Size = new System.Drawing.Size(59, 21);
            this.radioButtonMale.TabIndex = 37;
            this.radioButtonMale.TabStop = true;
            this.radioButtonMale.Text = "Male";
            this.radioButtonMale.UseVisualStyleBackColor = false;
            // 
            // btnExit
            // 
            this.btnExit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnExit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnExit.Image = global::GymManagementSystem.Properties.Resources.exit;
            this.btnExit.Location = new System.Drawing.Point(644, 335);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(127, 37);
            this.btnExit.TabIndex = 36;
            this.btnExit.Text = "Exit";
            this.btnExit.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnClear
            // 
            this.btnClear.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClear.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnClear.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnClear.Image = global::GymManagementSystem.Properties.Resources.edit_clear;
            this.btnClear.Location = new System.Drawing.Point(644, 290);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(127, 37);
            this.btnClear.TabIndex = 35;
            this.btnClear.Text = "Clear";
            this.btnClear.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAdd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnAdd.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnAdd.Image = global::GymManagementSystem.Properties.Resources.Save;
            this.btnAdd.Location = new System.Drawing.Point(644, 245);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(127, 37);
            this.btnAdd.TabIndex = 34;
            this.btnAdd.Text = "Add";
            this.btnAdd.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnAdd.UseVisualStyleBackColor = false;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnBrowse
            // 
            this.btnBrowse.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnBrowse.BackColor = System.Drawing.Color.Teal;
            this.btnBrowse.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnBrowse.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBrowse.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnBrowse.Image = global::GymManagementSystem.Properties.Resources._2_0501;
            this.btnBrowse.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnBrowse.Location = new System.Drawing.Point(737, 146);
            this.btnBrowse.Name = "btnBrowse";
            this.btnBrowse.Size = new System.Drawing.Size(96, 43);
            this.btnBrowse.TabIndex = 33;
            this.btnBrowse.Text = "add";
            this.btnBrowse.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnBrowse.UseVisualStyleBackColor = false;
            this.btnBrowse.Click += new System.EventHandler(this.btnBrowse_Click);
            // 
            // txtNIC
            // 
            this.txtNIC.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNIC.Location = new System.Drawing.Point(124, 142);
            this.txtNIC.Name = "txtNIC";
            this.txtNIC.Size = new System.Drawing.Size(132, 24);
            this.txtNIC.TabIndex = 32;
            // 
            // txtFee
            // 
            this.txtFee.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFee.Location = new System.Drawing.Point(385, 142);
            this.txtFee.Name = "txtFee";
            this.txtFee.Size = new System.Drawing.Size(132, 24);
            this.txtFee.TabIndex = 31;
            // 
            // txtAge
            // 
            this.txtAge.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAge.Location = new System.Drawing.Point(124, 100);
            this.txtAge.Name = "txtAge";
            this.txtAge.Size = new System.Drawing.Size(132, 24);
            this.txtAge.TabIndex = 29;
            // 
            // txtLName
            // 
            this.txtLName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLName.Location = new System.Drawing.Point(385, 56);
            this.txtLName.Name = "txtLName";
            this.txtLName.Size = new System.Drawing.Size(132, 24);
            this.txtLName.TabIndex = 28;
            // 
            // txtFname
            // 
            this.txtFname.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFname.Location = new System.Drawing.Point(124, 56);
            this.txtFname.Name = "txtFname";
            this.txtFname.Size = new System.Drawing.Size(132, 24);
            this.txtFname.TabIndex = 27;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(293, 146);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(32, 20);
            this.label5.TabIndex = 26;
            this.label5.Text = "Fee";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(27, 146);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(33, 20);
            this.label6.TabIndex = 25;
            this.label6.Text = "NIC";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(293, 104);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(57, 20);
            this.label3.TabIndex = 24;
            this.label3.Text = "Gender";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(27, 104);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(36, 20);
            this.label4.TabIndex = 23;
            this.label4.Text = "Age";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(293, 60);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 20);
            this.label2.TabIndex = 22;
            this.label2.Text = "Last Name";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(27, 60);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 20);
            this.label1.TabIndex = 21;
            this.label1.Text = "First Name";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.groupBox1.Controls.Add(this.txtPhoneTwo);
            this.groupBox1.Controls.Add(this.txtEmail);
            this.groupBox1.Controls.Add(this.txtFax);
            this.groupBox1.Controls.Add(this.txtAddress);
            this.groupBox1.Controls.Add(this.txtPhoneOne);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Location = new System.Drawing.Point(27, 209);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(507, 222);
            this.groupBox1.TabIndex = 13;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Contact Details";
            // 
            // txtPhoneTwo
            // 
            this.txtPhoneTwo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPhoneTwo.Location = new System.Drawing.Point(133, 65);
            this.txtPhoneTwo.Name = "txtPhoneTwo";
            this.txtPhoneTwo.Size = new System.Drawing.Size(352, 24);
            this.txtPhoneTwo.TabIndex = 37;
            // 
            // txtEmail
            // 
            this.txtEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmail.Location = new System.Drawing.Point(133, 139);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(352, 24);
            this.txtEmail.TabIndex = 36;
            // 
            // txtFax
            // 
            this.txtFax.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFax.Location = new System.Drawing.Point(133, 172);
            this.txtFax.Name = "txtFax";
            this.txtFax.Size = new System.Drawing.Size(352, 24);
            this.txtFax.TabIndex = 35;
            // 
            // txtAddress
            // 
            this.txtAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAddress.Location = new System.Drawing.Point(133, 102);
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(352, 24);
            this.txtAddress.TabIndex = 34;
            // 
            // txtPhoneOne
            // 
            this.txtPhoneOne.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPhoneOne.Location = new System.Drawing.Point(133, 28);
            this.txtPhoneOne.Name = "txtPhoneOne";
            this.txtPhoneOne.Size = new System.Drawing.Size(352, 24);
            this.txtPhoneOne.TabIndex = 33;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label10.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(19, 174);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(30, 20);
            this.label10.TabIndex = 31;
            this.label10.Text = "Fax";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label11.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(19, 139);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(46, 20);
            this.label11.TabIndex = 30;
            this.label11.Text = "Email";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(19, 104);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(62, 20);
            this.label7.TabIndex = 29;
            this.label7.Text = "Address";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(19, 69);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(90, 20);
            this.label8.TabIndex = 28;
            this.label8.Text = "Telephone 2";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(19, 32);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(90, 20);
            this.label9.TabIndex = 27;
            this.label9.Text = "Telephone 1";
            // 
            // picBoxProfile
            // 
            this.picBoxProfile.Image = global::GymManagementSystem.Properties.Resources.User_Folder__1_;
            this.picBoxProfile.Location = new System.Drawing.Point(602, 3);
            this.picBoxProfile.Name = "picBoxProfile";
            this.picBoxProfile.Size = new System.Drawing.Size(222, 167);
            this.picBoxProfile.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBoxProfile.TabIndex = 12;
            this.picBoxProfile.TabStop = false;
            // 
            // MPageDelete
            // 
            this.MPageDelete.Controls.Add(this.dataGridView1member);
            this.MPageDelete.Controls.Add(this.txtMemId);
            this.MPageDelete.Controls.Add(this.lblMemberId);
            this.MPageDelete.Controls.Add(this.btnClear2);
            this.MPageDelete.Controls.Add(this.buttonShow);
            this.MPageDelete.Controls.Add(this.btnDelete);
            this.MPageDelete.HorizontalScrollbarBarColor = true;
            this.MPageDelete.HorizontalScrollbarHighlightOnWheel = false;
            this.MPageDelete.HorizontalScrollbarSize = 10;
            this.MPageDelete.Location = new System.Drawing.Point(4, 38);
            this.MPageDelete.Name = "MPageDelete";
            this.MPageDelete.Size = new System.Drawing.Size(836, 443);
            this.MPageDelete.TabIndex = 1;
            this.MPageDelete.Text = "Delete";
            this.MPageDelete.VerticalScrollbarBarColor = true;
            this.MPageDelete.VerticalScrollbarHighlightOnWheel = false;
            this.MPageDelete.VerticalScrollbarSize = 10;
            // 
            // dataGridView1member
            // 
            this.dataGridView1member.AllowUserToAddRows = false;
            this.dataGridView1member.AllowUserToDeleteRows = false;
            this.dataGridView1member.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1member.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dataGridView1member.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1member.Location = new System.Drawing.Point(28, 123);
            this.dataGridView1member.Name = "dataGridView1member";
            this.dataGridView1member.ReadOnly = true;
            this.dataGridView1member.RowHeadersWidth = 51;
            this.dataGridView1member.RowTemplate.Height = 24;
            this.dataGridView1member.Size = new System.Drawing.Size(765, 295);
            this.dataGridView1member.TabIndex = 5;
            this.dataGridView1member.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1member_CellClick);
            this.dataGridView1member.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1member_CellClick);
            // 
            // txtMemId
            // 
            this.txtMemId.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMemId.Location = new System.Drawing.Point(192, 43);
            this.txtMemId.Name = "txtMemId";
            this.txtMemId.Size = new System.Drawing.Size(192, 24);
            this.txtMemId.TabIndex = 3;
            // 
            // lblMemberId
            // 
            this.lblMemberId.AutoSize = true;
            this.lblMemberId.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblMemberId.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblMemberId.Location = new System.Drawing.Point(24, 43);
            this.lblMemberId.Name = "lblMemberId";
            this.lblMemberId.Size = new System.Drawing.Size(145, 20);
            this.lblMemberId.TabIndex = 2;
            this.lblMemberId.Text = "Enter the member id";
            // 
            // btnClear2
            // 
            this.btnClear2.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.btnClear2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnClear2.Image = global::GymManagementSystem.Properties.Resources.edit_clear__1_;
            this.btnClear2.Location = new System.Drawing.Point(666, 30);
            this.btnClear2.Name = "btnClear2";
            this.btnClear2.Size = new System.Drawing.Size(127, 37);
            this.btnClear2.TabIndex = 8;
            this.btnClear2.Text = "Clear";
            this.btnClear2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnClear2.UseVisualStyleBackColor = false;
            this.btnClear2.Click += new System.EventHandler(this.button1_Click);
            // 
            // buttonShow
            // 
            this.buttonShow.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.buttonShow.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.buttonShow.Image = global::GymManagementSystem.Properties.Resources.eye1;
            this.buttonShow.Location = new System.Drawing.Point(28, 80);
            this.buttonShow.Name = "buttonShow";
            this.buttonShow.Size = new System.Drawing.Size(127, 37);
            this.buttonShow.TabIndex = 7;
            this.buttonShow.Text = "Show";
            this.buttonShow.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.buttonShow.UseVisualStyleBackColor = false;
            this.buttonShow.Click += new System.EventHandler(this.buttonShow_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.btnDelete.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnDelete.Image = global::GymManagementSystem.Properties.Resources.delete__1_;
            this.btnDelete.Location = new System.Drawing.Point(533, 30);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(127, 37);
            this.btnDelete.TabIndex = 4;
            this.btnDelete.Text = "Delete";
            this.btnDelete.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // MPageUpdate
            // 
            this.MPageUpdate.Controls.Add(this.rbFemale);
            this.MPageUpdate.Controls.Add(this.rbMale);
            this.MPageUpdate.Controls.Add(this.dataGridView2update);
            this.MPageUpdate.Controls.Add(this.addressTxt);
            this.MPageUpdate.Controls.Add(this.label25);
            this.MPageUpdate.Controls.Add(this.faxTxt);
            this.MPageUpdate.Controls.Add(this.label22);
            this.MPageUpdate.Controls.Add(this.emailTxt);
            this.MPageUpdate.Controls.Add(this.label23);
            this.MPageUpdate.Controls.Add(this.tel2Txt);
            this.MPageUpdate.Controls.Add(this.label24);
            this.MPageUpdate.Controls.Add(this.tel1Txt);
            this.MPageUpdate.Controls.Add(this.label17);
            this.MPageUpdate.Controls.Add(this.feeTxt);
            this.MPageUpdate.Controls.Add(this.label18);
            this.MPageUpdate.Controls.Add(this.nicTxt);
            this.MPageUpdate.Controls.Add(this.label19);
            this.MPageUpdate.Controls.Add(this.label20);
            this.MPageUpdate.Controls.Add(this.ageTxt);
            this.MPageUpdate.Controls.Add(this.label15);
            this.MPageUpdate.Controls.Add(this.lnameTxt);
            this.MPageUpdate.Controls.Add(this.label16);
            this.MPageUpdate.Controls.Add(this.fnameTxt);
            this.MPageUpdate.Controls.Add(this.label14);
            this.MPageUpdate.Controls.Add(this.memberIdTxt);
            this.MPageUpdate.Controls.Add(this.label13);
            this.MPageUpdate.Controls.Add(this.btnUpload);
            this.MPageUpdate.Controls.Add(this.buttonView);
            this.MPageUpdate.Controls.Add(this.buttonClear);
            this.MPageUpdate.Controls.Add(this.buttonUpdate);
            this.MPageUpdate.Controls.Add(this.pictureBoxUpdate);
            this.MPageUpdate.HorizontalScrollbarBarColor = true;
            this.MPageUpdate.HorizontalScrollbarHighlightOnWheel = false;
            this.MPageUpdate.HorizontalScrollbarSize = 10;
            this.MPageUpdate.Location = new System.Drawing.Point(4, 38);
            this.MPageUpdate.Name = "MPageUpdate";
            this.MPageUpdate.Size = new System.Drawing.Size(836, 443);
            this.MPageUpdate.TabIndex = 2;
            this.MPageUpdate.Text = "Update";
            this.MPageUpdate.VerticalScrollbarBarColor = true;
            this.MPageUpdate.VerticalScrollbarHighlightOnWheel = false;
            this.MPageUpdate.VerticalScrollbarSize = 10;
            // 
            // rbFemale
            // 
            this.rbFemale.AutoSize = true;
            this.rbFemale.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.rbFemale.Location = new System.Drawing.Point(199, 132);
            this.rbFemale.Name = "rbFemale";
            this.rbFemale.Size = new System.Drawing.Size(71, 21);
            this.rbFemale.TabIndex = 36;
            this.rbFemale.TabStop = true;
            this.rbFemale.Text = "female";
            this.rbFemale.UseVisualStyleBackColor = false;
            // 
            // rbMale
            // 
            this.rbMale.AutoSize = true;
            this.rbMale.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.rbMale.Location = new System.Drawing.Point(134, 132);
            this.rbMale.Name = "rbMale";
            this.rbMale.Size = new System.Drawing.Size(59, 21);
            this.rbMale.TabIndex = 35;
            this.rbMale.TabStop = true;
            this.rbMale.Text = "male";
            this.rbMale.UseVisualStyleBackColor = false;
            // 
            // dataGridView2update
            // 
            this.dataGridView2update.AllowUserToAddRows = false;
            this.dataGridView2update.AllowUserToDeleteRows = false;
            this.dataGridView2update.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2update.Location = new System.Drawing.Point(279, 120);
            this.dataGridView2update.Name = "dataGridView2update";
            this.dataGridView2update.ReadOnly = true;
            this.dataGridView2update.RowHeadersWidth = 51;
            this.dataGridView2update.RowTemplate.Height = 24;
            this.dataGridView2update.Size = new System.Drawing.Size(540, 311);
            this.dataGridView2update.TabIndex = 28;
            this.dataGridView2update.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2update_CellClick);
            // 
            // addressTxt
            // 
            this.addressTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addressTxt.Location = new System.Drawing.Point(134, 321);
            this.addressTxt.Name = "addressTxt";
            this.addressTxt.Size = new System.Drawing.Size(123, 24);
            this.addressTxt.TabIndex = 27;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label25.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label25.Location = new System.Drawing.Point(14, 321);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(62, 20);
            this.label25.TabIndex = 26;
            this.label25.Text = "Address";
            // 
            // faxTxt
            // 
            this.faxTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.faxTxt.Location = new System.Drawing.Point(134, 403);
            this.faxTxt.Name = "faxTxt";
            this.faxTxt.Size = new System.Drawing.Size(123, 24);
            this.faxTxt.TabIndex = 23;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label22.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label22.Location = new System.Drawing.Point(14, 403);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(30, 20);
            this.label22.TabIndex = 22;
            this.label22.Text = "Fax";
            // 
            // emailTxt
            // 
            this.emailTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.emailTxt.Location = new System.Drawing.Point(134, 357);
            this.emailTxt.Name = "emailTxt";
            this.emailTxt.Size = new System.Drawing.Size(123, 24);
            this.emailTxt.TabIndex = 21;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label23.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label23.Location = new System.Drawing.Point(14, 357);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(46, 20);
            this.label23.TabIndex = 20;
            this.label23.Text = "Email";
            // 
            // tel2Txt
            // 
            this.tel2Txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tel2Txt.Location = new System.Drawing.Point(134, 291);
            this.tel2Txt.Name = "tel2Txt";
            this.tel2Txt.Size = new System.Drawing.Size(123, 24);
            this.tel2Txt.TabIndex = 19;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label24.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label24.Location = new System.Drawing.Point(14, 291);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(90, 20);
            this.label24.TabIndex = 18;
            this.label24.Text = "Telephone 2";
            // 
            // tel1Txt
            // 
            this.tel1Txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tel1Txt.Location = new System.Drawing.Point(134, 257);
            this.tel1Txt.Name = "tel1Txt";
            this.tel1Txt.Size = new System.Drawing.Size(123, 24);
            this.tel1Txt.TabIndex = 17;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label17.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label17.Location = new System.Drawing.Point(14, 257);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(90, 20);
            this.label17.TabIndex = 16;
            this.label17.Text = "Telephone 1";
            // 
            // feeTxt
            // 
            this.feeTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.feeTxt.Location = new System.Drawing.Point(134, 217);
            this.feeTxt.Name = "feeTxt";
            this.feeTxt.Size = new System.Drawing.Size(123, 24);
            this.feeTxt.TabIndex = 15;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label18.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label18.Location = new System.Drawing.Point(14, 217);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(32, 20);
            this.label18.TabIndex = 14;
            this.label18.Text = "Fee";
            // 
            // nicTxt
            // 
            this.nicTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nicTxt.Location = new System.Drawing.Point(134, 171);
            this.nicTxt.Name = "nicTxt";
            this.nicTxt.Size = new System.Drawing.Size(123, 24);
            this.nicTxt.TabIndex = 13;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label19.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label19.Location = new System.Drawing.Point(14, 171);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(33, 20);
            this.label19.TabIndex = 12;
            this.label19.Text = "NIC";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label20.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label20.Location = new System.Drawing.Point(14, 131);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(57, 20);
            this.label20.TabIndex = 10;
            this.label20.Text = "Gender";
            // 
            // ageTxt
            // 
            this.ageTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ageTxt.Location = new System.Drawing.Point(134, 90);
            this.ageTxt.Name = "ageTxt";
            this.ageTxt.Size = new System.Drawing.Size(123, 24);
            this.ageTxt.TabIndex = 9;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label15.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label15.Location = new System.Drawing.Point(14, 97);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(36, 20);
            this.label15.TabIndex = 8;
            this.label15.Text = "Age";
            // 
            // lnameTxt
            // 
            this.lnameTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnameTxt.Location = new System.Drawing.Point(134, 57);
            this.lnameTxt.Name = "lnameTxt";
            this.lnameTxt.Size = new System.Drawing.Size(123, 24);
            this.lnameTxt.TabIndex = 7;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label16.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label16.Location = new System.Drawing.Point(14, 57);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(79, 20);
            this.label16.TabIndex = 6;
            this.label16.Text = "Last Name";
            // 
            // fnameTxt
            // 
            this.fnameTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fnameTxt.Location = new System.Drawing.Point(134, 27);
            this.fnameTxt.Name = "fnameTxt";
            this.fnameTxt.Size = new System.Drawing.Size(123, 24);
            this.fnameTxt.TabIndex = 5;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label14.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label14.Location = new System.Drawing.Point(14, 27);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(80, 20);
            this.label14.TabIndex = 4;
            this.label14.Text = "Frist Name";
            // 
            // memberIdTxt
            // 
            this.memberIdTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.memberIdTxt.Location = new System.Drawing.Point(428, 27);
            this.memberIdTxt.Name = "memberIdTxt";
            this.memberIdTxt.Size = new System.Drawing.Size(100, 24);
            this.memberIdTxt.TabIndex = 3;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label13.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label13.Location = new System.Drawing.Point(275, 31);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(147, 20);
            this.label13.TabIndex = 2;
            this.label13.Text = "Enter the member ID";
            // 
            // btnUpload
            // 
            this.btnUpload.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btnUpload.Image = global::GymManagementSystem.Properties.Resources._2_0502;
            this.btnUpload.Location = new System.Drawing.Point(770, 66);
            this.btnUpload.Name = "btnUpload";
            this.btnUpload.Size = new System.Drawing.Size(40, 39);
            this.btnUpload.TabIndex = 34;
            this.btnUpload.UseVisualStyleBackColor = false;
            this.btnUpload.Click += new System.EventHandler(this.btnUpload_Click);
            // 
            // buttonView
            // 
            this.buttonView.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.buttonView.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.buttonView.Image = global::GymManagementSystem.Properties.Resources.eye;
            this.buttonView.Location = new System.Drawing.Point(534, 65);
            this.buttonView.Name = "buttonView";
            this.buttonView.Size = new System.Drawing.Size(124, 37);
            this.buttonView.TabIndex = 33;
            this.buttonView.Text = "View";
            this.buttonView.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonView.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.buttonView.UseVisualStyleBackColor = false;
            this.buttonView.Click += new System.EventHandler(this.buttonView_Click);
            // 
            // buttonClear
            // 
            this.buttonClear.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.buttonClear.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.buttonClear.Image = global::GymManagementSystem.Properties.Resources.edit_clear__1_;
            this.buttonClear.Location = new System.Drawing.Point(408, 65);
            this.buttonClear.Name = "buttonClear";
            this.buttonClear.Size = new System.Drawing.Size(124, 37);
            this.buttonClear.TabIndex = 32;
            this.buttonClear.Text = "Clear";
            this.buttonClear.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonClear.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.buttonClear.UseVisualStyleBackColor = false;
            this.buttonClear.Click += new System.EventHandler(this.buttonClear_Click);
            // 
            // buttonUpdate
            // 
            this.buttonUpdate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.buttonUpdate.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.buttonUpdate.Image = global::GymManagementSystem.Properties.Resources.update;
            this.buttonUpdate.Location = new System.Drawing.Point(282, 66);
            this.buttonUpdate.Name = "buttonUpdate";
            this.buttonUpdate.Size = new System.Drawing.Size(124, 37);
            this.buttonUpdate.TabIndex = 31;
            this.buttonUpdate.Text = "Update";
            this.buttonUpdate.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonUpdate.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.buttonUpdate.UseVisualStyleBackColor = false;
            this.buttonUpdate.Click += new System.EventHandler(this.buttonUpdate_Click);
            // 
            // pictureBoxUpdate
            // 
            this.pictureBoxUpdate.Location = new System.Drawing.Point(669, 9);
            this.pictureBoxUpdate.Name = "pictureBoxUpdate";
            this.pictureBoxUpdate.Size = new System.Drawing.Size(128, 93);
            this.pictureBoxUpdate.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxUpdate.TabIndex = 29;
            this.pictureBoxUpdate.TabStop = false;
            // 
            // MPageView
            // 
            this.MPageView.Controls.Add(this.btnView);
            this.MPageView.Controls.Add(this.button2);
            this.MPageView.Controls.Add(this.txt_search);
            this.MPageView.Controls.Add(this.label27);
            this.MPageView.Controls.Add(this.dataGridView3Search);
            this.MPageView.Controls.Add(this.pictureBox1);
            this.MPageView.HorizontalScrollbarBarColor = true;
            this.MPageView.HorizontalScrollbarHighlightOnWheel = false;
            this.MPageView.HorizontalScrollbarSize = 10;
            this.MPageView.Location = new System.Drawing.Point(4, 38);
            this.MPageView.Name = "MPageView";
            this.MPageView.Size = new System.Drawing.Size(836, 443);
            this.MPageView.TabIndex = 3;
            this.MPageView.Text = "Veiw";
            this.MPageView.VerticalScrollbarBarColor = true;
            this.MPageView.VerticalScrollbarHighlightOnWheel = false;
            this.MPageView.VerticalScrollbarSize = 10;
            // 
            // txt_search
            // 
            this.txt_search.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_search.Location = new System.Drawing.Point(131, 18);
            this.txt_search.Name = "txt_search";
            this.txt_search.Size = new System.Drawing.Size(100, 24);
            this.txt_search.TabIndex = 5;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label27.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label27.Location = new System.Drawing.Point(18, 22);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(84, 20);
            this.label27.TabIndex = 4;
            this.label27.Text = "Member ID";
            // 
            // dataGridView3Search
            // 
            this.dataGridView3Search.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3Search.Location = new System.Drawing.Point(15, 74);
            this.dataGridView3Search.Name = "dataGridView3Search";
            this.dataGridView3Search.RowHeadersWidth = 51;
            this.dataGridView3Search.RowTemplate.Height = 24;
            this.dataGridView3Search.Size = new System.Drawing.Size(818, 325);
            this.dataGridView3Search.TabIndex = 2;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(759, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(74, 65);
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(25, 9);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(249, 29);
            this.label26.TabIndex = 1;
            this.label26.Text = "Member Management";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button2.Location = new System.Drawing.Point(237, 13);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(74, 35);
            this.button2.TabIndex = 43;
            this.button2.Text = "select";
            this.button2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // btnView
            // 
            this.btnView.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnView.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnView.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnView.Location = new System.Drawing.Point(15, 395);
            this.btnView.Name = "btnView";
            this.btnView.Size = new System.Drawing.Size(99, 35);
            this.btnView.TabIndex = 44;
            this.btnView.Text = "View";
            this.btnView.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnView.UseVisualStyleBackColor = false;
            this.btnView.Click += new System.EventHandler(this.btnView_Click);
            // 
            // member
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ClientSize = new System.Drawing.Size(899, 560);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.MemberTabBox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "member";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "member";
            this.MemberTabBox.ResumeLayout(false);
            this.MPageAdd.ResumeLayout(false);
            this.MPageAdd.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxProfile)).EndInit();
            this.MPageDelete.ResumeLayout(false);
            this.MPageDelete.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1member)).EndInit();
            this.MPageUpdate.ResumeLayout(false);
            this.MPageUpdate.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2update)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxUpdate)).EndInit();
            this.MPageView.ResumeLayout(false);
            this.MPageView.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3Search)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroTabControl MemberTabBox;
        private MetroFramework.Controls.MetroTabPage MPageAdd;
        private MetroFramework.Controls.MetroTabPage MPageDelete;
        private MetroFramework.Controls.MetroTabPage MPageUpdate;
        private MetroFramework.Controls.MetroTabPage MPageView;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.PictureBox picBoxProfile;
        private System.Windows.Forms.TextBox txtLName;
        private System.Windows.Forms.TextBox txtFname;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtAge;
        private System.Windows.Forms.TextBox txtNIC;
        private System.Windows.Forms.TextBox txtFee;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnBrowse;
        private System.Windows.Forms.TextBox txtPhoneTwo;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.TextBox txtFax;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.TextBox txtPhoneOne;
        private System.Windows.Forms.RadioButton radioButtonFemale;
        private System.Windows.Forms.RadioButton radioButtonMale;
        private System.Windows.Forms.TextBox txt_memId;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtMemId;
        private System.Windows.Forms.Label lblMemberId;
        private System.Windows.Forms.DataGridView dataGridView1member;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button buttonShow;
        private System.Windows.Forms.Button btnClear2;
        private System.Windows.Forms.DataGridView dataGridView3Search;
        private System.Windows.Forms.TextBox memberIdTxt;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox fnameTxt;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox faxTxt;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox emailTxt;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox tel2Txt;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox tel1Txt;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox feeTxt;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox nicTxt;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox ageTxt;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox lnameTxt;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button buttonView;
        private System.Windows.Forms.Button buttonClear;
        private System.Windows.Forms.Button buttonUpdate;
        private System.Windows.Forms.PictureBox pictureBoxUpdate;
        private System.Windows.Forms.DataGridView dataGridView2update;
        private System.Windows.Forms.TextBox addressTxt;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Button btnUpload;
        private System.Windows.Forms.RadioButton rbFemale;
        private System.Windows.Forms.RadioButton rbMale;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox txt_search;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnView;
        private System.Windows.Forms.Button button2;
    }
}