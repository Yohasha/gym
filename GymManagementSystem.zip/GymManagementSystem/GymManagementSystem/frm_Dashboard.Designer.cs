﻿
namespace GymManagementSystem
{
    partial class frm_Dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.btn_logout = new MetroFramework.Controls.MetroButton();
            this.btn_hep = new MetroFramework.Controls.MetroButton();
            this.btn_settings = new MetroFramework.Controls.MetroButton();
            this.btn_accounts = new MetroFramework.Controls.MetroButton();
            this.btn_inventory = new MetroFramework.Controls.MetroButton();
            this.btn_staff = new MetroFramework.Controls.MetroButton();
            this.btn_member = new MetroFramework.Controls.MetroButton();
            this.btn_dashboard = new MetroFramework.Controls.MetroButton();
            this.metroButton9 = new MetroFramework.Controls.MetroButton();
            this.metroButton10 = new MetroFramework.Controls.MetroButton();
            this.metroButton11 = new MetroFramework.Controls.MetroButton();
            this.metroPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // metroPanel1
            // 
            this.metroPanel1.Controls.Add(this.btn_logout);
            this.metroPanel1.Controls.Add(this.btn_hep);
            this.metroPanel1.Controls.Add(this.btn_settings);
            this.metroPanel1.Controls.Add(this.btn_accounts);
            this.metroPanel1.Controls.Add(this.btn_inventory);
            this.metroPanel1.Controls.Add(this.btn_staff);
            this.metroPanel1.Controls.Add(this.btn_member);
            this.metroPanel1.Controls.Add(this.btn_dashboard);
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            this.metroPanel1.Location = new System.Drawing.Point(28, 25);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Size = new System.Drawing.Size(230, 644);
            this.metroPanel1.TabIndex = 0;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            // 
            // btn_logout
            // 
            this.btn_logout.Location = new System.Drawing.Point(0, 563);
            this.btn_logout.Name = "btn_logout";
            this.btn_logout.Size = new System.Drawing.Size(230, 81);
            this.btn_logout.TabIndex = 9;
            this.btn_logout.Text = "Logout";
            this.btn_logout.UseSelectable = true;
            // 
            // btn_hep
            // 
            this.btn_hep.Location = new System.Drawing.Point(0, 482);
            this.btn_hep.Name = "btn_hep";
            this.btn_hep.Size = new System.Drawing.Size(230, 84);
            this.btn_hep.TabIndex = 8;
            this.btn_hep.Text = "Help";
            this.btn_hep.UseSelectable = true;
            // 
            // btn_settings
            // 
            this.btn_settings.Location = new System.Drawing.Point(0, 402);
            this.btn_settings.Name = "btn_settings";
            this.btn_settings.Size = new System.Drawing.Size(230, 84);
            this.btn_settings.TabIndex = 7;
            this.btn_settings.Text = "Settings";
            this.btn_settings.UseSelectable = true;
            // 
            // btn_accounts
            // 
            this.btn_accounts.Location = new System.Drawing.Point(0, 322);
            this.btn_accounts.Name = "btn_accounts";
            this.btn_accounts.Size = new System.Drawing.Size(230, 84);
            this.btn_accounts.TabIndex = 6;
            this.btn_accounts.Text = "Accounts";
            this.btn_accounts.UseSelectable = true;
            // 
            // btn_inventory
            // 
            this.btn_inventory.Location = new System.Drawing.Point(0, 241);
            this.btn_inventory.Name = "btn_inventory";
            this.btn_inventory.Size = new System.Drawing.Size(230, 84);
            this.btn_inventory.TabIndex = 5;
            this.btn_inventory.Text = "Inventary ";
            this.btn_inventory.UseSelectable = true;
            // 
            // btn_staff
            // 
            this.btn_staff.Location = new System.Drawing.Point(0, 161);
            this.btn_staff.Name = "btn_staff";
            this.btn_staff.Size = new System.Drawing.Size(230, 84);
            this.btn_staff.TabIndex = 4;
            this.btn_staff.Text = "Staff";
            this.btn_staff.UseSelectable = true;
            this.btn_staff.Click += new System.EventHandler(this.btn_staff_Click);
            // 
            // btn_member
            // 
            this.btn_member.Location = new System.Drawing.Point(0, 80);
            this.btn_member.Name = "btn_member";
            this.btn_member.Size = new System.Drawing.Size(230, 84);
            this.btn_member.TabIndex = 3;
            this.btn_member.Text = "Member";
            this.btn_member.UseSelectable = true;
            this.btn_member.Click += new System.EventHandler(this.btn_member_Click);
            // 
            // btn_dashboard
            // 
            this.btn_dashboard.Location = new System.Drawing.Point(0, 0);
            this.btn_dashboard.Name = "btn_dashboard";
            this.btn_dashboard.Size = new System.Drawing.Size(230, 84);
            this.btn_dashboard.TabIndex = 2;
            this.btn_dashboard.Text = "Dashboard";
            this.btn_dashboard.UseSelectable = true;
            // 
            // metroButton9
            // 
            this.metroButton9.Location = new System.Drawing.Point(322, 218);
            this.metroButton9.Name = "metroButton9";
            this.metroButton9.Size = new System.Drawing.Size(159, 132);
            this.metroButton9.TabIndex = 10;
            this.metroButton9.Text = "Dashboard";
            this.metroButton9.UseSelectable = true;
            this.metroButton9.Click += new System.EventHandler(this.metroButton9_Click);
            // 
            // metroButton10
            // 
            this.metroButton10.Location = new System.Drawing.Point(676, 25);
            this.metroButton10.Name = "metroButton10";
            this.metroButton10.Size = new System.Drawing.Size(159, 132);
            this.metroButton10.TabIndex = 11;
            this.metroButton10.Text = "Dashboard";
            this.metroButton10.UseSelectable = true;
            // 
            // metroButton11
            // 
            this.metroButton11.Location = new System.Drawing.Point(492, 25);
            this.metroButton11.Name = "metroButton11";
            this.metroButton11.Size = new System.Drawing.Size(159, 132);
            this.metroButton11.TabIndex = 12;
            this.metroButton11.Text = "Dashboard";
            this.metroButton11.UseSelectable = true;
            // 
            // frm_Dashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(904, 695);
            this.Controls.Add(this.metroButton11);
            this.Controls.Add(this.metroButton10);
            this.Controls.Add(this.metroButton9);
            this.Controls.Add(this.metroPanel1);
            this.Name = "frm_Dashboard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frm_Dashboard";
            this.metroPanel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Controls.MetroPanel metroPanel1;
        private MetroFramework.Controls.MetroButton btn_dashboard;
        private MetroFramework.Controls.MetroButton btn_member;
        private MetroFramework.Controls.MetroButton btn_logout;
        private MetroFramework.Controls.MetroButton btn_hep;
        private MetroFramework.Controls.MetroButton btn_settings;
        private MetroFramework.Controls.MetroButton btn_accounts;
        private MetroFramework.Controls.MetroButton btn_inventory;
        private MetroFramework.Controls.MetroButton btn_staff;
        private MetroFramework.Controls.MetroButton metroButton9;
        private MetroFramework.Controls.MetroButton metroButton10;
        private MetroFramework.Controls.MetroButton metroButton11;
    }
}