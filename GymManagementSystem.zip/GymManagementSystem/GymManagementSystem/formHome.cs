﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GymManagementSystem
{
    public partial class formHome : Form
    {
        public formHome()
        {
            InitializeComponent();
            customizeDesign();
        }

        private void customizeDesign()
        {
            panelAccountsSubMenu.Visible = false;
            panelStaffSubMenu.Visible = false;
            panelMemberSubMenu.Visible = false;
            panelInventorySubMenu.Visible = false;

        }

        private void hideSubmenu()
        {
            if (panelMemberSubMenu.Visible == true)
                panelMemberSubMenu.Visible = false;

            if (panelStaffSubMenu.Visible == true)
                panelStaffSubMenu.Visible = false;

            if (panelAccountsSubMenu.Visible == true)
                panelAccountsSubMenu.Visible = false;

            if (panelInventorySubMenu.Visible == true)
                panelInventorySubMenu.Visible = false;
        }

        private void showSubMenu(Panel subMenu)
        {
            if (subMenu.Visible == false)
            {
                hideSubmenu();
                subMenu.Visible = true;
            }
            else
            {
                subMenu.Visible = false;
            }
        }

        private void buttonMember_Click(object sender, EventArgs e)
        {
            // showSubMenu(panelMemberSubMenu);
            openChildform(new member());
        }

        private void button2_Click(object sender, EventArgs e)
        {
          
            hideSubmenu();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            hideSubmenu();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            hideSubmenu();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            hideSubmenu();
        }

        private void buttonStaff_Click(object sender, EventArgs e)
        {
           // showSubMenu(panelStaffSubMenu);
            openChildform(new frmStaff());

        }
        private void button10_Click(object sender, EventArgs e)
        {
            hideSubmenu();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            hideSubmenu();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            hideSubmenu();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            hideSubmenu();
        }

        private void buttonInventory_Click(object sender, EventArgs e)
        {
            //showSubMenu(panelInventorySubMenu);
            openChildform(new frmInventory());
        }

        private void button15_Click(object sender, EventArgs e)
        {
            hideSubmenu();
        }

        private void button14_Click(object sender, EventArgs e)
        {
            hideSubmenu();
        }

        private void button13_Click(object sender, EventArgs e)
        {
            hideSubmenu();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            hideSubmenu();
        }

        private void buttonAccounts_Click(object sender, EventArgs e)
        {
            //showSubMenu(panelAccountsSubMenu);
            openChildform(new salaryForm());
        }

        private void button17_Click(object sender, EventArgs e)
        {
            hideSubmenu();
        }

        private void button16_Click(object sender, EventArgs e)
        {
            hideSubmenu();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            hideSubmenu();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            hideSubmenu();
            this.Close();
        }

        private Form activeForm = null;
        private void openChildform(Form childForm)
        {
            if (activeForm != null)
                activeForm.Close();
            activeForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            panelChidForm.Controls.Add(childForm);
            panelChidForm.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();
        }

        private void panelChidForm_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button11_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void buttonMember_MouseEnter(object sender, EventArgs e)
        {
            
        }
    }
}

    

       